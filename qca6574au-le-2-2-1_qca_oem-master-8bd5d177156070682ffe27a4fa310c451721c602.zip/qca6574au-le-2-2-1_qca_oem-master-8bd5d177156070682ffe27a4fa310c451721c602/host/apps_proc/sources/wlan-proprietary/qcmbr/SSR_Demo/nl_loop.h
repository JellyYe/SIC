/**
 * Copyright (c) 2014,2019 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */
#ifndef __NL_LOOP_H_
#define __NL_LOOP_H_


/*---------------------------------------------------------------------------
 * Preprocessor Definitions and Constants
 *-------------------------------------------------------------------------*/
#define WLAN_NL_MAX_PAYLOAD   256     /* maximum size for netlink message*/
#define WLAN_NLINK_PROTO_FAMILY  NETLINK_USERSOCK
#define WLAN_NLINK_MCAST_GRP_ID  0x01


#define ANI_NL_MSG_BASE     0x10    /* Some arbitrary base */

typedef enum eAniNlModuleTypes {
   ANI_NL_MSG_PUMAC = ANI_NL_MSG_BASE + 0x01,// PTT Socket App
   ANI_NL_MSG_PTT   = ANI_NL_MSG_BASE + 0x07,// Quarky GUI
   WLAN_NL_MSG_BTC,
   WLAN_NL_MSG_OEM,
   WLAN_NL_MSG_SVC,
   WLAN_NL_MSG_CNSS_DIAG = ANI_NL_MSG_BASE + 0x0B,//Value needs to be 27
   ANI_NL_MSG_LOG,
   ANI_NL_MSG_MAX
} tAniNlModTypes, tWlanNlModTypes;


// Special Message Type used by SoftAP, intercepted by send_btc_nlink_msg() and
// replaced by WLAN_STA_ASSOC_DONE_IND
#define WLAN_BTC_SOFTAP_BSS_START   0x11
#define WLAN_SVC_FW_CRASHED_IND     0x100
#define WLAN_SVC_LTE_COEX_IND       0x101
#define WLAN_SVC_WLAN_AUTO_SHUTDOWN_IND 0x102
#define WLAN_SVC_DFS_CAC_START_IND      0x103
#define WLAN_SVC_DFS_CAC_END_IND        0x104
#define WLAN_SVC_DFS_RADAR_DETECT_IND   0x105
#define WLAN_SVC_WLAN_STATUS_IND    0x106
#define WLAN_SVC_WLAN_VERSION_IND   0x107
#define WLAN_SVC_DFS_ALL_CHANNEL_UNAVAIL_IND 0x108
#define WLAN_SVC_WLAN_TP_IND        0x109
#define WLAN_SVC_RPS_ENABLE_IND     0x10A
#define WLAN_SVC_WLAN_TP_TX_IND     0x10B
#define WLAN_SVC_WLAN_AUTO_SHUTDOWN_CANCEL_IND 0x10C
#define WLAN_SVC_WLAN_RADIO_INDEX 0x10D
#define WLAN_SVC_FW_SHUTDOWN_IND  0x10E

//All Netlink messages must contain this header
typedef struct sAniHdr {
   unsigned short type;
   unsigned short length;
} tAniHdr, tAniMsgHdr;

struct radio_index_tlv {
   unsigned short type;
   unsigned short length;
   int radio;
};



typedef void (*nl_loop_ind_handler)(unsigned short type, void *user_data, int radio);

int nl_loop_init(void);
int nl_loop_deinit(void);
int nl_loop_register(int ind, nl_loop_ind_handler ind_handler, void *user_data);
int nl_loop_unregister(int ind);

int nl_loop_terminate(void);
int nl_loop_run(void);

#endif  /* __NL_LOOP_H_ */
