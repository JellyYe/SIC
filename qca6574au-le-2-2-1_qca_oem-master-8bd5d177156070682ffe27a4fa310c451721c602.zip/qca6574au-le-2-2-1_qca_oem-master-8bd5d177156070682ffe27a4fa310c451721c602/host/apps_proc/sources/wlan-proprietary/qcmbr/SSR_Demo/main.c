/**
 * Copyright (c) 2014,2019 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <getopt.h>
#include "debug.h"
#include "nl_loop.h"

#define  DAEMONIZE      0x1
#define  LOG_FILE       0x2
#define  SYS_LOG        0x4
#define BUFFER_SIZE  256

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(_arr) (sizeof(_arr) / sizeof((_arr)[0]))
#endif

#define MAX_MODULE_NUMBER 2
#define MAX_MODULE_NAME_LENGTH 240
static char mod_name[MAX_MODULE_NAME_LENGTH];
static unsigned short mod_num = 0;


extern int wsvc_debug_level;
static char *progname = NULL;

static void wlan_svc_unload_driver(char *module_name)
{
   char strBuffer[BUFFER_SIZE];
   strBuffer[0] = '\0';
   int n = 0;

   n = snprintf(strBuffer, BUFFER_SIZE, "rmmod %s",module_name);
   if (n > 0)
	system(strBuffer);
}

static void wlan_svc_load_driver(char *module_name)
{
    char strBuffer[BUFFER_SIZE];
    strBuffer[0] = '\0';
    int n = 0;

    n = snprintf(strBuffer, BUFFER_SIZE, "insmod /lib/modules/`uname -r`/extra/%s.ko",module_name);
    if (n > 0)
        system(strBuffer);

}

static inline int wlan_svc_aquire_wake_lock(void)
{
    wsvc_printf_dbg("Aquiring wake lock");

    return system("echo SSR_Demo > /sys/power/wake_lock");
}

static inline int wlan_svc_release_wake_lock(void)
{
    wsvc_printf_dbg("Releasing wake lock");

    return system("echo SSR_Demo > /sys/power/wake_unlock");
}

static void wlan_svc_restart(unsigned short type, void *user_data, int radio)
{
    wsvc_printf_dbg("Restarting WLAN: %u, %p", type, user_data);

    char mn_with_idx[BUFFER_SIZE];
    int radio_index = (radio == 0) ? 0 : 2;

    //for dual module, module name should be appended by radio index
    if (mod_num > 1) {
        snprintf(mn_with_idx, BUFFER_SIZE, "%s%d", mod_name, radio_index);
    } else {
        snprintf(mn_with_idx, BUFFER_SIZE, "%s", mod_name);
    }

    wlan_svc_unload_driver(mn_with_idx);

    wlan_svc_load_driver(mn_with_idx);

    return;
}

static void wlan_svc_shutdown(unsigned short type, void *user_data, int radio)
{
    wsvc_printf_dbg("Shutdown WLAN: %u, %p", type, user_data);

    system("rmmod wlan.ko");

    return;
}

static struct ind_handlers {
    unsigned short ind;
    nl_loop_ind_handler handler;
    void *user_data;
} ind_handlers [] = {
    {
        .ind = WLAN_SVC_FW_CRASHED_IND,
        .handler = wlan_svc_restart,
        .user_data = NULL,
    },
    {
        .ind = WLAN_SVC_LTE_COEX_IND,
        .handler = wlan_svc_restart,
        .user_data = NULL,
    },
    {
        .ind = WLAN_SVC_WLAN_AUTO_SHUTDOWN_IND,
        .handler = wlan_svc_shutdown,
        .user_data = NULL,
    },
};

static void usage(void)
{
    fprintf(stderr, "usage: %s [options]\n"
            "   -n, --nodaemon  do not run as a daemon\n"
            "   -d              show more debug messages (-dd for even more)\n"
#ifdef CONFIG_DEBUG_FILE
            "   -f <path/file>  Log output to file\n"
#endif
#ifdef CONFIG_DEBUG_SYSLOG
            "   -s              Log output to syslog\n"
#endif
            "   -m  --mod_name <module_name,module_numbers> specify the module name,eg. -m wlan-cnss,2\n"
            "                  0 < module_name_length < 240, 0 < module_numbers <= 2\n"
            "       --help      display this help and exit\n"
            , progname);
    exit(EXIT_FAILURE);
}

static void wlan_service_sighandler(int signum)
{
    wsvc_printf_info("Caught Signal: %d", signum);
    nl_loop_terminate();

    return;
}

static int wlan_service_setup_sighandler(void)
{
    struct sigaction sig_act;

    memset(&sig_act, 0, sizeof(sig_act));
    sig_act.sa_handler = wlan_service_sighandler;
    sigemptyset(&sig_act.sa_mask);

    sigaction(SIGQUIT, &sig_act, NULL);
    sigaction(SIGTERM, &sig_act, NULL);
    sigaction(SIGINT, &sig_act, NULL);
    sigaction(SIGHUP, &sig_act, NULL);

    return 0;
}

int main(int argc, char *argv[])
{
    int c;
    int i;
    int flag = DAEMONIZE;
    static struct option options[] =
    {
        {"help", no_argument, NULL, 'h'},
        {"nodaemon", no_argument, NULL, 'n'},
	{"mod_name", required_argument, NULL, 'm'},
        {0, 0, 0, 0}
    };
    char *log_file = NULL;

    progname = argv[0];

    while (1) {
        c = getopt_long(argc, argv, "hdnf:sm:", options, NULL);

        if (c < 0)
            break;

        switch (c) {
        case 'n':
            flag &= ~DAEMONIZE;
            break;
        case 'd':
#ifdef CONFIG_DEBUG
            wsvc_debug_level++;
#else
            wsvc_printf_err("Debugging disabled, please build with -DDEBUG");
            exit(EXIT_FAILURE);
#endif
            break;
#ifdef CONFIG_DEBUG_FILE
        case 'f':
            log_file = optarg;
            flag |= LOG_FILE;
            break;
#endif /* CONFIG_DEBUG_FILE */
#ifdef CONFIG_DEBUG_SYSLOG
        case 's':
            flag |= SYS_LOG;
            break;
#endif /* CONFIG_DEBUG_SYSLOG */

        case 'h':
	    break;

	case 'm':
            if (optarg != NULL) {
                unsigned int i = 0;
                while(*optarg != '\0') {
                    if (*optarg != ',') {
                        if (i == (MAX_MODULE_NAME_LENGTH)) {
                            wsvc_printf_err("too long module name, exiting\n");
                            return -1;
                        }
                        mod_name[i++] = *optarg;
                        optarg++;
                    }
                    else {
                        mod_name[i] = '\0';
                        optarg++;//skip the comma
                        mod_num = atoi(optarg++);
                    }
                }
            }
            break;

        default:
            usage();
            break;
        }
    }

    if (mod_num <= 0 || mod_num > MAX_MODULE_NUMBER) {
        wsvc_printf_err("please specify the module name, and correct module numbers\n");
        usage();
    }

    if (optind < argc)
        usage();

    wsvc_debug_init();

    if (flag & SYS_LOG)
        wsvc_debug_open_syslog();
    else if (flag & LOG_FILE)
        wsvc_debug_open_file(log_file);

    wlan_service_setup_sighandler();

    if (flag & DAEMONIZE && daemon(0, 0)) {
        wsvc_perror("daemon");
        exit(EXIT_FAILURE);
    }
    if (nl_loop_init()) {
        wsvc_printf_err("Failed to init nl_loop");
        goto out;
    }

    for (i = 0; i < ARRAY_SIZE(ind_handlers); i++) {
        if (nl_loop_register(ind_handlers[i].ind, ind_handlers[i].handler,
                    NULL)) {
            wsvc_printf_err("Failed to register: %d, %x", i,
                    ind_handlers[i].ind);
            goto register_fail;
        }
    }

    nl_loop_run();

register_fail:
    while (--i >= 0)
        nl_loop_unregister(ind_handlers[i].ind);

    nl_loop_deinit();

out:

    wsvc_debug_close_syslog();
    wsvc_debug_close_file();

    exit(EXIT_SUCCESS);
}
