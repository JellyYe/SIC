/*
Copyright (c)  2012-2013, 2016-2019 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.


   Copyright (c) 2007, 2008        Johannes Berg
   Copyright (c) 2007              Andy Lutomirski
   Copyright (c) 2007              Mike Kershaw
   Copyright (c) 2008-2009         Luis R. Rodriguez

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

* Driver interaction with Linux nl80211/cfg80211
 * Copyright (c) 2002-2015, Jouni Malinen <j@w1.fi>
 * Copyright (c) 2003-2004, Instant802 Networks, Inc.
 * Copyright (c) 2005-2006, Devicescape Software, Inc.
 * Copyright (c) 2007, Johannes Berg <johannes@sipsolutions.net>
 * Copyright (c) 2009-2010, Atheros Communications
 *
 * This software may be distributed under the terms of the BSD license.
 * See README for more details.
*/

#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <poll.h>
#include <sys/types.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <linux/if_ether.h>
#include <linux/if.h>
#include <netlink/genl/ctrl.h>
#include <netlink/genl/genl.h>
#include <netlink/genl/family.h>
#include <netlink/socket.h>
#include <netlink/attr.h>
#include <linux/nl80211.h>
#include <linux/socket.h>
#include <linux/types.h>
#include <inttypes.h>
#include <sys/stat.h>

typedef unsigned  bool;

uint8_t debug_enable = 0;

#define MAX_BSSIDS_TO_SCAN  10
#define ETH_ALEN 6
#define MAX_NLMSG_LEN 5120
#define BAND_2G_BEGIN 1
#define BAND_2G_END   14
#define BAND_5G_BEGIN 34
#define BAND_5G_END   165
#define MAX_CHANNEL_ID  165
#define BSSID_IE 0x00
#define VENDOR_SPECIFIC_IE 0xdd
#define RSN_IE 0x30
#define CELL_POWER_INFO_IE 0x96
#define COUNTRY_CODE_IE 0x7
#define SUPPORTED_RATES_IE 1
#define EXT_SUPPORTED_RATES_IE 50
#define HT_CAP_IE          45
#define HT_OPERATION_IE    61
#define VHT_CAP_IE         191
#define VHT_OPERATION_IE   192
#define EXTENDED_CAP_IE    127
#define EXTENDED_CAP_11MC_SUPPORTED_BIT 70
#define EXTENDED_CAP_LOC_CIVIC_SUPPORTED_BIT 14
#define EXTENDED_CAP_LCI_SUPPORTED_BIT 15
#define EXTENDED_CAP_INTW_ANQP_SUPPORTED_BIT 31
/** definitions used in location_features_supported  */
#define LCI_SUPPORTED_MASK    0x00000001
#define LOC_CIVIC_SUPPORTED_MASK    0x00000002
#define ANQP_SUPPORTED_MASK    0x00000004
#define NUM_11G_RATES 8
static const uint8_t elevenGRates[NUM_11G_RATES] = { 6, 9, 12, 18, 24, 36, 48, 54 };
#define SUPPORTED_RATE_MASK 0x7F
#define BASIC_RATE_MASK    0x80
#define HT_CAP_40MHZ_SUPPORTED_BIT 1
#define HT_CAP_PROHIBIT_40MHZ_BIT 14
#define MAX_2G_CHANNEL 14
#define HT_OP_SEC_CH_NOT_PRESENT 0      /* No Seconday Channel present */
#define HT_OP_SEC_CH_ABOVE_PRIMARY_CH 1 /* Seconday Channel is above the Primary Channel */
#define HT_OP_SEC_CH_BELOW_PRIMARY_CH 3 /* Seconday Channel is below the Primary Channel */
#define IS_2G_CHANNEL(x) ((x >= BAND_2G_BEGIN) && (x <= BAND_2G_END))
#define PHY_MODE_MASK  0xFFFFFFC0

typedef uint8_t  wmi_mac_addr[8]; // for byte alignment

enum {
    false = 0,
    true = 1
};

struct ucred {
    uint32_t pid;
    uint32_t uid;
    uint32_t gid;
};

typedef enum
{
    ROME_PHY_MODE_11A           = 0,  /* 11a Mode */
    ROME_PHY_MODE_11G           = 1,  /* 11b/g Mode */
    ROME_PHY_MODE_11B           = 2,  /* 11b Mode */
    ROME_PHY_MODE_11GONLY       = 3,  /* 11g only Mode */
    ROME_PHY_MODE_11NA_HT20     = 4,  /* 11na HT20 mode */
    ROME_PHY_MODE_11NG_HT20     = 5,  /* 11ng HT20 mode */
    ROME_PHY_MODE_11NA_HT40     = 6,  /* 11na HT40 mode */
    ROME_PHY_MODE_11NG_HT40     = 7,  /* 11ng HT40 mode */
    ROME_PHY_MODE_11AC_VHT20    = 8,  /* 5G 11ac VHT20 mode */
    ROME_PHY_MODE_11AC_VHT40    = 9,  /* 5G 11ac VHT40 mode */
    ROME_PHY_MODE_11AC_VHT80    = 10, /* 5G 11ac VHT80 mode */
    ROME_PHY_MODE_11AC_VHT20_2G = 11, /* 2G 11ac VHT20 mode */
    ROME_PHY_MODE_11AC_VHT40_2G = 12, /* 2G 11ac VHT40 mode */
    ROME_PHY_MODE_11AC_VHT80_2G = 13, /* 2G 11ac VHT80 mode */
    ROME_PHY_MODE_UNKNOWN       = 14,
    ROME_PHY_MODE_MAX           = 14
} ROME_PHY_MODE;

struct nl80211_state {
    struct nl_sock *nl_sock;
    struct genl_family * nl80211_family_ptr;
    struct nl_cache * nl_cache;
    unsigned int nl80211_id;
    int scanmcid;
    struct nl_cb *s_cb;
    bool nlInitialized;
};

struct s_wait_event {
    int n_cmds;
    const uint32_t *cmds;
    uint32_t cmd;
    void *pargs;
};

struct handler_args {
    const char *group;
    int id;
};

typedef enum
{
    TWO_POINT_FOUR_GHZ = 0,
    FIVE_GHZ = 1,
    BAND_ALL
}eBand;

typedef enum
{
    regReq,
    chanInfoReq,
    rangeCapReq,
    rangeScanReq,
    maxReq
}cmdType;

enum eNodeType
{
    NODE_TYPE_UNKNOWN = 0,
    ACCESS_POINT,
    PEER_DEVICE,
    NAN_DEVICE,
    STA_DEVICE,
    SOFT_AP
};

typedef enum {
    RTT_WMI_VDEV_TYPE_AP        = 0x1,
    RTT_WMI_VDEV_TYPE_STA       = 0x2,
    RTT_WMI_VDEV_TYPE_NAN       = 0x3,
    RTT_WMI_VDEV_TYPE_P2P_GO    = 0x4,
    RTT_WMI_VDEV_TYPE_P2P_CLI   = 0x5,
} wmi_rtt_vdev_type;

const int channelArr_2_4_ghz[] =
{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

const int freqArr_2_4_ghz[] =
{2412, 2417, 2422, 2427, 2432, 2437, 2442, 2447,
  2452, 2457, 2462, 2467, 2472, 2484};

const int channelArr_5_ghz[] =
{36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108,
  112, 116, 132, 136, 140, 149, 153, 157, 161, 165};

const int freqArr_5_ghz[] =
{5180, 5200, 5220, 5240, 5260, 5280, 5300, 5320, 5500, 5520, 5540,
  5560, 5580, 5660, 5680, 5700, 5745, 5765, 5785, 5805, 5825};

#define ANI_DRIVER_MSG_START         0x0001
#define ANI_MSG_APP_REG_REQ         (ANI_DRIVER_MSG_START + 0)
#define ANI_MSG_APP_REG_RSP         (ANI_DRIVER_MSG_START + 1)
#define ANI_MSG_OEM_DATA_REQ        (ANI_DRIVER_MSG_START + 2)
#define ANI_MSG_OEM_DATA_RSP        (ANI_DRIVER_MSG_START + 3)
#define ANI_MSG_CHANNEL_INFO_REQ    (ANI_DRIVER_MSG_START + 4)
#define ANI_MSG_CHANNEL_INFO_RSP    (ANI_DRIVER_MSG_START + 5)
#define ANI_MSG_OEM_ERROR           (ANI_DRIVER_MSG_START + 6)
#define ANI_MSG_PEER_STATUS_IND     (ANI_DRIVER_MSG_START + 7)

#define ANI_NL_MSG_BASE     0x10

typedef enum eAniNlModuleTypes
{
    ANI_NL_MSG_PUMAC = ANI_NL_MSG_BASE + 0x01,
    ANI_NL_MSG_PTT = ANI_NL_MSG_BASE + 0x07,
    WLAN_NL_MSG_BTC,
    WLAN_NL_MSG_OEM,
    ANI_NL_MSG_MAX
} tAniNlModTypes, tWlanNlModTypes;

/* ANI Message Header */
typedef struct
{
    uint16_t type;
    uint16_t length;
}tAniHdr, tAniMsgHdr;


#define APP_REG_SIGNATURE  "QUALCOMM-OEM-APP"
#define APP_REG_SIGNATURE_LENGTH  (sizeof(APP_REG_SIGNATURE) - 1)

#define CAP_SINGLE_SIDED_RANGING  0x1
#define CAP_DOUBLE_SIDED_RANGING  0x2
#define CAP_11MC_DOUBLE_SIDED_RANGING  0x4

#define RTT_VERSION_MAJOR    1
#define RTT_VERSION_MINOR    0
#define RTT_REVISION  1

/* Format of the version number. */
#define RTT_VER_MAJOR_BIT_OFFSET        24
#define RTT_VER_MINOR_BIT_OFFSET        0

#define RTT_VER_MAJOR_BIT_MASK          0xFF000000
#define RTT_VER_MINOR_BIT_MASK          0x00FFFFFF

#define RTT_VER_SET_VERSION(major, minor)  ( (( major << RTT_VER_MAJOR_BIT_OFFSET ) & RTT_VER_MAJOR_BIT_MASK) + (( minor << RTT_VER_MINOR_BIT_OFFSET ) & RTT_VER_MINOR_BIT_MASK) )

typedef uint32_t  OemMsgSubType;

#define TARGET_OEM_CAPABILITY_REQ       0x01
#define TARGET_OEM_CAPABILITY_RSP       0x02
#define TARGET_OEM_MEASUREMENT_REQ      0x03
#define TARGET_OEM_MEASUREMENT_RSP      0x04
#define TARGET_OEM_ERROR_REPORT_RSP     0x05
#define TARGET_OEM_NAN_MEAS_REQ         0x06
#define TARGET_OEM_NAN_MEAS_RSP         0x07
#define TARGET_OEM_NAN_PEER_INFO        0x08
#define TARGET_OEM_CONFIGURE_LCR        0x09
#define TARGET_OEM_CONFIGURE_LCI        0x0A
#define TARGET_OEM_LCI_REQ              0x80
#define TARGET_OEM_FTMR_REQ             0x81

enum eRttType
{
    RTT1_RANGING = 0,
    RTT2_RANGING,
    RTT3_RANGING,
    BEST_EFFORT_RANGING
};

/* RTT functional defines start here */
#define RTT_REPORT_PER_FRAME_WITH_CFR 0
#define RTT_REPORT_PER_FRAME_NO_CFR   1
#define RTT_AGGREGATE_REPORT_NON_CFR  2

#define RTT_MEAS_FRAME_NULL 0
#define RTT_MEAS_FRAME_QOSNULL 1
#define RTT_MEAS_FRAME_TMR 2

#define WIFI_MAC_ID_SIZE 6

typedef struct
{
    uint8_t mac[WIFI_MAC_ID_SIZE];
    uint8_t rttFrameType;
    uint8_t bandwidth;
    uint8_t preamble;
    uint8_t numFrames;
    uint8_t numFrameRetries;
    uint8_t vDevType;

    /*** FTMR related fields */
    uint32_t ftmParams;
    uint32_t tsfDelta;
    bool tsfValid;
} DestInfo;

typedef struct
{
    uint32_t mhz;
    uint32_t band_center_freq1;
    uint32_t band_center_freq2;
    uint32_t info;
    uint32_t reg_info_1;
    uint32_t reg_info_2;
}wmi_channel;

typedef struct
{
    uint32_t chId;
    wmi_channel wmiChannelInfo;
} ChannelInfo;

typedef struct
{
    uint32_t chan_id;
    uint32_t reserved0;
    wmi_channel channel_info;
}Ani_channel_info;

typedef enum device_mode
{
    WLAN_HDD_INFRA_STATION,
    WLAN_HDD_SOFTAP,
    WLAN_HDD_P2P_CLIENT,
    WLAN_HDD_P2P_GO,
    WLAN_HDD_MONITOR,
    WLAN_HDD_FTM,
    WLAN_HDD_IBSS,
    WLAN_HDD_P2P_DEVICE,
    WLAN_HDD_MAX_DEV_MODE
} device_mode_t;

typedef struct
{
    uint8_t iFaceId;
    uint8_t vDevId;
}VDevMap;

typedef struct
{
    uint8_t numInterface;
    VDevMap vDevMap[WLAN_HDD_MAX_DEV_MODE];
}VDevInfo;

#define WMI_F_MS(_v, _f)                   \
    ( ((_v) & (_f)) >> (_f##_S) )

#define WMI_F_RMW(_var, _v, _f)              \
    do {                                     \
    (_var) &= ~(_f);                         \
    (_var) |= ( ((_v) << (_f##_S)) & (_f)); \
    } while (0)

/*RTT Req Command Macros */
#define WMI_RTT_NUM_CHAN_S  0
#define WMI_RTT_NUM_CHAN  (0xff << WMI_RTT_NUM_CHAN_S)
#define WMI_RTT_NUM_CHAN_GET(x)  WMI_F_MS(x,WMI_RTT_NUM_CHAN)
#define WMI_RTT_NUM_CHAN_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_NUM_CHAN)

#define WMI_RTT_FRAME_TYPE_S  0
#define WMI_RTT_FRAME_TYPE  (7 << WMI_RTT_FRAME_TYPE_S)
#define WMI_RTT_FRAME_TYPE_GET(x)  WMI_F_MS(x,WMI_RTT_FRAME_TYPE)
#define WMI_RTT_FRAME_TYPE_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_FRAME_TYPE)

#define WMI_RTT_TX_CHAIN_S  3
#define WMI_RTT_TX_CHAIN  (0xf << WMI_RTT_TX_CHAIN_S)
#define WMI_RTT_TX_CHAIN_GET(x)  WMI_F_MS(x,WMI_RTT_TX_CHAIN)
#define WMI_RTT_TX_CHAIN_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_TX_CHAIN)

#define WMI_RTT_RX_CHAIN_S  7
#define WMI_RTT_RX_CHAIN  (0xf << WMI_RTT_RX_CHAIN_S)
#define WMI_RTT_RX_CHAIN_GET(x)  WMI_F_MS(x,WMI_RTT_RX_CHAIN)
#define WMI_RTT_RX_CHAIN_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_RX_CHAIN)

#define WMI_RTT_QCA_PEER_S  11
#define WMI_RTT_QCA_PEER  (0x1 << WMI_RTT_QCA_PEER_S)
#define WMI_RTT_QCA_PEER_GET(x)  WMI_F_MS(x,WMI_RTT_QCA_PEER)
#define WMI_RTT_QCA_PEER_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_QCA_PEER)

#define WMI_RTT_BW_S  12
#define WMI_RTT_BW  (0x3 <<WMI_RTT_BW_S)
#define WMI_RTT_BW_GET(x)  WMI_F_MS(x,WMI_RTT_BW)
#define WMI_RTT_BW_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_BW)

#define WMI_RTT_PREAMBLE_S  15
#define WMI_RTT_PREAMBLE  (0x3 <<WMI_RTT_PREAMBLE_S)
#define WMI_RTT_PREAMBLE_GET(x)  WMI_F_MS(x,WMI_RTT_PREAMBLE)
#define WMI_RTT_PREAMBLE_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_PREAMBLE)

#define WMI_RTT_RETRIES_S  17
#define WMI_RTT_RETRIES  (0xf << WMI_RTT_RETRIES_S)
#define WMI_RTT_RETRIES_GET(x)  WMI_F_MS(x,WMI_RTT_RETRIES)
#define WMI_RTT_RETRIES_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_RETRIES)

#define WMI_RTT_MCS_S  21
#define WMI_RTT_MCS  (0xff << WMI_RTT_MCS_S)
#define WMI_RTT_MCS_GET(x)  WMI_F_MS(x,WMI_RTT_MCS)
#define WMI_RTT_MCS_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_MCS)

#define WMI_RTT_VDEV_TYPE_S  0
#define WMI_RTT_VDEV_TYPE  (0xf << WMI_RTT_VDEV_TYPE_S)
#define WMI_RTT_VDEV_TYPE_GET(x)  WMI_F_MS(x,WMI_RTT_VDEV_TYPE)
#define WMI_RTT_VDEV_TYPE_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_VDEV_TYPE)

#define WMI_RTT_MEAS_NUM_S  4
#define WMI_RTT_MEAS_NUM  (0xff << WMI_RTT_MEAS_NUM_S)
#define WMI_RTT_MEAS_NUM_GET(x)  WMI_F_MS(x,WMI_RTT_MEAS_NUM)
#define WMI_RTT_MEAS_NUM_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_MEAS_NUM)

#define WMI_RTT_TIMEOUT_S  12
#define WMI_RTT_TIMEOUT  (0xff << WMI_RTT_TIMEOUT_S)
#define WMI_RTT_TIMEOUT_GET(x)  WMI_F_MS(x,WMI_RTT_TIMEOUT)
#define WMI_RTT_TIMEOUT_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_TIMEOUT)

#define WMI_RTT_REPORT_TYPE_S  20
#define WMI_RTT_REPORT_TYPE  (0x3 <<WMI_RTT_REPORT_TYPE_S)
#define WMI_RTT_REPORT_TYPE_GET(x)  WMI_F_MS(x,WMI_RTT_REPORT_TYPE)
#define WMI_RTT_REPORT_TYPE_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_REPORT_TYPE)

#define WMI_RTT_NUM_STA_S  0
#define WMI_RTT_NUM_STA  (0xff << WMI_RTT_NUM_STA_S)
#define WMI_RTT_NUM_STA_GET(x)  WMI_F_MS(x,WMI_RTT_NUM_STA)
#define WMI_RTT_NUM_STA_SET(x,z)  WMI_F_RMW(x,z,WMI_RTT_NUM_STA)

enum eRangingPreamble
{
    RTT_PREAMBLE_LEGACY = 0,
    RTT_PREAMBLE_HT,
    RTT_PREAMBLE_VHT,
    RTT_PREAMBLE_MAX
};

#define FRAME_TYPE_NULL     0   /* RTT Type 2 */
#define FRAME_TYPE_QOS_NULL 1   /* RTT Type 2 */
#define FRAME_TYPE_TMR      2   /* RTT Type 3 */

#define TX_CHAIN_1          0x1
#define TX_CHAIN_2          0x2
#define TX_CHAIN_3          0x4

#define RX_CHAIN_1          0x1
#define RX_CHAIN_2          0x2
#define RX_CHAIN_3          0x4

#define ROME_PREAMBLE_LEGACY     0
#define ROME_PREAMBLE_CCK        1
#define ROME_PREAMBLE_HT         2
#define ROME_PREAMBLE_VHT        3

#define RTT_TIMEOUT_PER_TARGET 50

#define RTT_SERVICE_BITMASK_SZ  4

typedef struct
{
    uint32_t tlv_header;
    uint32_t version;
    uint32_t revision;
} wmi_rtt_oem_cap_req_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t channel_cnt;
} wmi_rtt_oem_measreq_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t sta_num;
}wmi_rtt_oem_measreq_per_channel_info;

typedef struct
{
    uint32_t tlv_header;
    uint32_t control_flag;
    uint32_t measure_info;
    wmi_mac_addr dest_mac;
    wmi_mac_addr spoof_bssid;
    uint32_t measure_params_1;
    uint32_t measure_params_2;
} wmi_rtt_oem_measreq_peer_info;

 typedef struct
{
    uint32_t tlv_header;
    uint32_t sub_type;
    uint32_t req_id;
    uint32_t pdev_id;
} wmi_rtt_oem_req_head;

#define RTT_TLV_HDR_SIZE   (1 * sizeof(uint32_t))

#define WMIRTT_TLV_SET_HDR(tlv_buf, tag, len) (((uint32_t *)(tlv_buf))[0]) = ((tag << 16) | (len & 0x0000FFFF))

typedef enum
{
    WMIRTT_TLV_TAG_UNKNOWN= 0,
    /* 0 to 15 is reserved */
    WMIRTT_TLV_TAG_LAST_RESERVED = 15,
    WMIRTT_TLV_TAG_STRUC_loop_start,
    WMIRTT_TLV_TAG_STRUC_loop_end,
    WMIRTT_TLV_TAG_FIRST_ARRAY_ENUM, /* First entry of ARRAY type tags */
    WMIRTT_TLV_TAG_ARRAY_UINT8 = WMIRTT_TLV_TAG_FIRST_ARRAY_ENUM,
    WMIRTT_TLV_TAG_LAST_ARRAY_ENUM = 31,   /* Last entry of ARRAY type tags */
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_req_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_req_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_rsp_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_rsp_event,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measreq_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_channel_info,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measreq_per_channel_info,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measreq_peer_info,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measrsp_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_peer_event_hdr,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_nan_ranging_info,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_nan_req_cmd,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_lcr_cfg_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_lci_cfg_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_get_channel_info_req_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_get_channel_info_rsp_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_set_responder_mode_req_head,
    WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_set_responder_mode_rsp_head
} WMIRTT_TLV_TAG_ID;

/* RTT message subtype definitions */
typedef enum {
    RTT_MSG_SUBTYPE_INVALID                  = 0x00,
    RTT_MSG_SUBTYPE_CAPABILITY_REQ           = 0x01,
    RTT_MSG_SUBTYPE_CAPABILITY_RSP           = 0x02,
    RTT_MSG_SUBTYPE_MEASUREMENT_REQ          = 0x03,
    RTT_MSG_SUBTYPE_MEASUREMENT_RSP          = 0x04,
    RTT_MSG_SUBTYPE_ERROR_REPORT_RSP         = 0x05,
    RTT_MSG_SUBTYPE_CONFIGURE_LCR            = 0x06,
    RTT_MSG_SUBTYPE_CONFIGURE_LCI            = 0x07,
    RTT_MSG_SUBTYPE_CLEANUP_REQ              = 0x08,
    RTT_MSG_SUBTYPE_CLEANUP_RSP              = 0x09,
    RTT_MSG_SUBTYPE_GET_CHANNEL_INFO_REQ     = 0x10, //REQ for channel info
    RTT_MSG_SUBTYPE_GET_CHANNEL_INFO_RSP     = 0x11, // RESPONSE for channel info
    RTT_MSG_SUBTYPE_CFG_RESPONDER_MODE_REQ   = 0x12, // REQ for  enable or disable responder mode
    RTT_MSG_SUBTYPE_CFG_RESPONDER_MODE_RSP   = 0x13, // RESPONSE for enable mode
} WMIRTT_OEM_MSG_SUBTYPE;

/*-----------Rome RTT Capabilities Response Message--------*/
typedef struct
{
    #define CAP_SINGLE_SIDED_RANGING  0x1
    #define CAP_DOUBLE_SIDED_RANGING  0x2
    #define CAP_11MC_DOUBLE_SIDED_RANGING  0x4
    uint8_t rangingTypeMask;

    #define CAP_NULL_FRAME      0x1
    #define CAP_QOS_NULL_FRAME  0x2
    #define CAP_TMR_TM_FRAMES   0x4
    #define CAP_FTMR_FTM_FRAMES 0x8
    #define CAP_RTS_CTS_FRAMES  0x10
    uint8_t supportedFramesMask;

    uint8_t maxDestPerReq;

    uint8_t maxMeasPerDest;

    uint8_t maxChannelsAllowed;

    #define RTT_CAP_BW_20     0x0
    #define RTT_CAP_BW_40     0x1
    #define RTT_CAP_BW_80     0x2
    #define RTT_CAP_BW_160    0x3
    uint8_t maxBwAllowed;

    #define CAP_PREAMBLE_LEGACY 0x1
    #define CAP_PREAMBLE_HT     0x2
    #define CAP_PREAMBLE_VHT    0x4
    uint8_t preambleSupportedMask;

    #define CAP_REPORT_0  0x1
    #define CAP_REPORT_1  0x2
    #define CAP_REPORT_2  0x4
    uint8_t reportTypeSupportedMask;

    uint8_t maxRfChains;

    #define CAP_NO_FAC  0x1
    #define CAP_SW_IFFT 0x2
    #define CAP_HW_IFFT 0x4
    uint8_t facTypeMask;

    uint8_t numPhys;

    uint8_t fwMultiBurstSupport;
}RomeRttCapabilities;

typedef enum
{
    ROME_REG_RSP_MSG,
    ROME_CHANNEL_INFO_MSG,
    ROME_P2P_PEER_EVENT_MSG,
    ROME_CLD_ERROR_MSG,
    ROME_WIPHY_INFO_MSG,
    ROME_RANGING_CAP_MSG,
    ROME_RANGING_MEAS_MSG,
    ROME_RANGING_ERROR_MSG,
    ROME_RTT_CHANNEL_INFO_MSG,
    ROME_RESPONDER_INFO_MSG,
    ROME_FTM_SESSION_DONE_MSG,
    ROME_NL_ERROR_MSG,
    ROME_MSG_MAX
} RomeNlMsgType;

/** Defines the Bandwidth for Ranging scan */
enum eRangingBandwidth
{
    BW_20MHZ = 0,
    BW_40MHZ,
    BW_80MHZ,
    BW_160MHZ,
    BW_MAX
};

#define NON_QTI_PEER        0
#define QTI_PEER            1

#define LEGACY_6MBPS_MCS   3
#define VHT_HT_6_5MBPS_MCS 0

  #define FTM_ASAP_BIT               0
  #define FTM_LCI_BIT                1
  #define FTM_LOC_CIVIC_BIT          2
  #define FTM_PTSF_TIMER_NO_PREF     3
  #define FTM_AOA_MEASUREMENT        4
  #define FTM_LEG_ACK_ONLY           5
  #define FTM_BURSTS_EXP_START_BIT   8
  #define FTM_BURSTS_EXP_MASK        0xF
  #define FTM_BURST_DUR_START_BIT    12
  #define FTM_BURST_DUR_MASK         0xF
  #define FTM_BURST_PERIOD_START_BIT 16
  #define FTM_BURST_PERIOD_MASK      0xFFFF

  #define FTM_SET_ASAP(x) (x = (x | (1 << FTM_ASAP_BIT)))
  #define FTM_CLEAR_ASAP(x) (x = (x & ~(1 << FTM_ASAP_BIT)))
  #define FTM_GET_ASAP(x) ((x & (1 << FTM_ASAP_BIT)) >> FTM_ASAP_BIT)

  #define FTM_SET_LCI_REQ(x) (x = (x | (1 << FTM_LCI_BIT)))
  #define FTM_CLEAR_LCI_REQ(x) (x = (x & ~(1 << FTM_LCI_BIT)))
  #define FTM_GET_LCI_REQ(x) ((x & (1 << FTM_LCI_BIT)) >> FTM_LCI_BIT)

  #define FTM_SET_LOC_CIVIC_REQ(x) (x = (x | (1 << FTM_LOC_CIVIC_BIT)))
  #define FTM_CLEAR_LOC_CIVIC_REQ(x) (x = (x & ~(1 << FTM_LOC_CIVIC_BIT)))
  #define FTM_GET_LOC_CIVIC_REQ(x) ((x & (1 << FTM_LOC_CIVIC_BIT)) >> FTM_LOC_CIVIC_BIT)

  #define FTM_SET_PTSF_TIMER_NO_PREF(x) (x = (x | (1 << FTM_PTSF_TIMER_NO_PREF)))
  #define FTM_CLEAR_PTSF_TIMER_NO_PREF(x) (x = (x & ~(1 << FTM_PTSF_TIMER_NO_PREF)))
  #define FTM_GET_PTSF_TIMER_NO_PREF(x) ((x & (1 << FTM_PTSF_TIMER_NO_PREF)) >> FTM_PTSF_TIMER_NO_PREF)

  #define FTM_SET_AOA_MEASUREMENT(x) (x = (x | (1 << FTM_AOA_MEASUREMENT)))
  #define FTM_CLEAR_AOA_MEASUREMENT(x) (x = (x & ~(1 << FTM_AOA_MEASUREMENT)))
  #define FTM_GET_AOA_MEASUREMENT(x) ((x & (1 << FTM_AOA_MEASUREMENT)) >> FTM_AOA_MEASUREMENT)

  #define FTM_SET_BURSTS_EXP(x,y) (x = ((x & ~(FTM_BURSTS_EXP_MASK << FTM_BURSTS_EXP_START_BIT)) | (y << FTM_BURSTS_EXP_START_BIT)))
  #define FTM_GET_BURSTS_EXP(x)   ((x & (FTM_BURSTS_EXP_MASK << FTM_BURSTS_EXP_START_BIT)) >> FTM_BURSTS_EXP_START_BIT)

  #define FTM_SET_BURST_DUR(x,y) (x = ((x & ~(FTM_BURST_DUR_MASK << FTM_BURST_DUR_START_BIT)) | (y << FTM_BURST_DUR_START_BIT)))
  #define FTM_GET_BURST_DUR(x) ((x & (FTM_BURST_DUR_MASK << FTM_BURST_DUR_START_BIT)) >> FTM_BURST_DUR_START_BIT)

  #define FTM_SET_BURST_PERIOD(x,y) (x = ((x & ~(FTM_BURST_PERIOD_MASK << FTM_BURST_PERIOD_START_BIT)) | (y << FTM_BURST_PERIOD_START_BIT)))
  #define FTM_GET_BURST_PERIOD(x) ((x & (FTM_BURST_PERIOD_MASK << FTM_BURST_PERIOD_START_BIT)) >> FTM_BURST_PERIOD_START_BIT)

  #define FTM_SET_LEG_ACK_ONLY(x) (x = (x | (1 << FTM_LEG_ACK_ONLY)))
  #define FTM_CLEAR_LEG_ACK_ONLY(x) (x = (x & ~(1 << FTM_LEG_ACK_ONLY)))
  #define FTM_GET_LEG_ACK_ONLY(x) ((x & (1 << FTM_LEG_ACK_ONLY)) >> FTM_LEG_ACK_ONLY)


#define WMI_RTT_ASAP_MODE_S 0
#define WMI_RTT_ASAP_MODE (0x1 <<WMI_RTT_ASAP_MODE_S)
#define WMI_RTT_ASAP_MODE_GET(x) WMI_F_MS(x,WMI_RTT_ASAP_MODE)
#define WMI_RTT_ASAP_MODE_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_ASAP_MODE)

#define WMI_RTT_LCI_REQ_S 1
#define WMI_RTT_LCI_REQ (0x1 <<WMI_RTT_LCI_REQ_S)
#define WMI_RTT_LCI_REQ_GET(x) WMI_F_MS(x,WMI_RTT_LCI_REQ)
#define WMI_RTT_LCI_REQ_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_LCI_REQ)

#define WMI_RTT_LOC_CIV_REQ_S 2
#define WMI_RTT_LOC_CIV_REQ (0x1 <<WMI_RTT_LOC_CIV_REQ_S)
#define WMI_RTT_LOC_CIV_REQ_GET(x) WMI_F_MS(x,WMI_RTT_LOC_CIV_REQ)
#define WMI_RTT_LOC_CIV_REQ_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_LOC_CIV_REQ)

#define WMI_RTT_NUM_BURST_EXP_S 4
#define WMI_RTT_NUM_BURST_EXP (0xf <<WMI_RTT_NUM_BURST_EXP_S)
#define WMI_RTT_NUM_BURST_EXP_GET(x) WMI_F_MS(x,WMI_RTT_NUM_BURST_EXP)
#define WMI_RTT_NUM_BURST_EXP_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_NUM_BURST_EXP)

#define WMI_RTT_BURST_DUR_S 8
#define WMI_RTT_BURST_DUR (0xf <<WMI_RTT_BURST_DUR_S)
#define WMI_RTT_BURST_DUR_GET(x) WMI_F_MS(x,WMI_RTT_BURST_DUR)
#define WMI_RTT_BURST_DUR_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_BURST_DUR)

#define WMI_RTT_PTSF_TIMER_S 3
#define WMI_RTT_PTSF_TIMER (0x1 <<WMI_RTT_PTSF_TIMER_S)
#define WMI_RTT_PTSF_TIMER_GET(x) WMI_F_MS(x,WMI_RTT_PTSF_TIMER)
#define WMI_RTT_PTSF_TIMER_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_PTSF_TIMER)

#define WMI_RTT_BURST_PERIOD_S 12
#define WMI_RTT_BURST_PERIOD (0xffff <<WMI_RTT_BURST_PERIOD_S)
#define WMI_RTT_BURST_PERIOD_GET(x) WMI_F_MS(x,WMI_RTT_BURST_PERIOD)
#define WMI_RTT_BURST_PERIOD_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_BURST_PERIOD)

#define WMI_RTT_TSF_DELTA_S 0
#define WMI_RTT_TSF_DELTA (0xffffffff <<WMI_RTT_TSF_DELTA_S)
#define WMI_RTT_TSF_DELTA_GET(x) WMI_F_MS(x,WMI_RTT_TSF_DELTA)
#define WMI_RTT_TSF_DELTA_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_TSF_DELTA)

/* RTT report macros */
#define WMI_RTT_REPORT_REQ_ID_S 0
#define WMI_RTT_REPORT_REQ_ID (0xffff << WMI_RTT_REPORT_REQ_ID_S)
#define WMI_RTT_REPORT_REQ_ID_GET(x) WMI_F_MS(x, WMI_RTT_REPORT_REQ_ID)
#define WMI_RTT_REPORT_REQ_ID_SET(x,z) WMI_F_RMW(x,z, WMI_RTT_REPORT_REQ_ID)

#define WMI_RTT_REPORT_STATUS_S 16
#define WMI_RTT_REPORT_STATUS (0x1 << WMI_RTT_REPORT_STATUS_S)
#define WMI_RTT_REPORT_STATUS_GET(x) WMI_F_MS(x, WMI_RTT_REPORT_STATUS)
#define WMI_RTT_REPORT_STATUS_SET(x,z) WMI_F_RMW(x,z, WMI_RTT_REPORT_STATUS)

#define WMI_RTT_REPORT_FINISH_S 9
#define WMI_RTT_REPORT_FINISH (0x1 << WMI_RTT_REPORT_FINISH_S)
#define WMI_RTT_REPORT_FINISH_GET(x) WMI_F_MS(x, WMI_RTT_REPORT_FINISH)
#define WMI_RTT_REPORT_FINISH_SET(x,z) WMI_F_RMW(x,z, WMI_RTT_REPORT_FINISH)

#define WMI_RTT_REPORT_MEAS_TYPE_S 10
#define WMI_RTT_REPORT_MEAS_TYPE (0x1f << WMI_RTT_REPORT_MEAS_TYPE_S)
#define WMI_RTT_REPORT_MEAS_TYPE_GET(x) WMI_F_MS(x, WMI_RTT_REPORT_MEAS_TYPE)
#define WMI_RTT_REPORT_MEAS_TYPE_SET(x,z) WMI_F_RMW(x,z, WMI_RTT_REPORT_MEAS_TYPE)

#define WMI_RTT_REPORT_REPORT_TYPE_S 0
#define WMI_RTT_REPORT_REPORT_TYPE (0xff << WMI_RTT_REPORT_REPORT_TYPE_S)
#define WMI_RTT_REPORT_REPORT_TYPE_GET(x) WMI_F_MS(x, WMI_RTT_REPORT_REPORT_TYPE)
#define WMI_RTT_REPORT_REPORT_TYPE_SET(x,z) WMI_F_RMW(x,z, WMI_RTT_REPORT_REPORT_TYPE)

#define WMI_RTT_REPORT_NUM_AP_S 20     /* used for only Report Type 2 3*/
#define WMI_RTT_REPORT_NUM_AP (0xf << WMI_RTT_REPORT_NUM_AP_S)
#define WMI_RTT_REPORT_NUM_AP_GET(x) WMI_F_MS(x,WMI_RTT_REPORT_NUM_AP)
#define WMI_RTT_REPORT_NUM_AP_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_REPORT_NUM_AP)

#define WMI_RTT_REPORT_CHAN_INFO_S 0
#define WMI_RTT_REPORT_CHAN_INFO (0xffffffff << WMI_RTT_REPORT_CHAN_INFO_S)
#define WMI_RTT_REPORT_CHAN_INFO_GET(x) WMI_F_MS(x, WMI_RTT_REPORT_CHAN_INFO)
#define WMI_RTT_REPORT_CHAN_INFO_SET(x,z) WMI_F_RMW(x,z, WMI_RTT_REPORT_CHAN_INFO)

#define WMI_RTT_SUB_TYPE_S 0
#define WMI_RTT_SUB_TYPE (0xffffffff << WMI_RTT_SUB_TYPE_S)
#define WMI_RTT_SUB_TYPE_GET(x) WMI_F_MS(x,WMI_RTT_SUB_TYPE)
#define WMI_RTT_SUB_TYPE_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_SUB_TYPE)

#define WMI_RTT_FORCE_LEGACY_ACK_S 29
#define WMI_RTT_FORCE_LEGACY_ACK (0x1 << WMI_RTT_FORCE_LEGACY_ACK_S)
#define WMI_RTT_FORCE_LEGACY_ACK_GET(x) WMI_F_MS(x,WMI_RTT_FORCE_LEGACY_ACK)
#define WMI_RTT_FORCE_LEGACY_ACK_SET(x,z) WMI_F_RMW(x,z,WMI_RTT_FORCE_LEGACY_ACK)

typedef struct
{
    uint32_t time32;     //upper 32 bits of time stamp
    uint32_t time0;      //lower 32 bits of time stamp
} time64;

typedef struct
{
    uint32_t tlv_header;
    uint32_t sub_type;
    uint32_t req_id;
    uint32_t fragment_info;
    uint32_t pdev_id;
} wmi_rtt_oem_rsp_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t info;
    wmi_mac_addr dest_mac;
    uint32_t channel_info;
} wmi_rtt_oem_measrsp_head;

typedef struct
{
    uint32_t info;
    uint32_t bytes;
}wmi_rtt_oem_ie;

typedef struct
{
    uint32_t tlv_header;
    wmi_mac_addr dest_mac;
    uint32_t control;
    uint32_t result_info1;
    uint32_t result_info2;
    uint32_t result_info3;
    uint32_t meas_start_tsf;
} wmi_rtt_oem_per_peer_event_hdr;

typedef struct
{
    uint32_t tlv_header;
    uint32_t rssi;
    time64 t1;
    time64 t2;
    uint32_t t3_del;
    uint32_t t4_del;
    uint32_t tx_rate_info_1;
    uint32_t tx_rate_info_2;
    uint32_t rx_rate_info_1;
    uint32_t rx_rate_info_2;
    uint32_t max_tod_toa_error;
} wmi_rtt_oem_per_frame_info;

typedef struct
{
    uint32_t tlv_header;
    uint32_t version;
    uint32_t revision;
    uint32_t service_bitmask[RTT_SERVICE_BITMASK_SZ];
} wmi_rtt_oem_cap_rsp_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t support;
    uint32_t cap;
    uint32_t cap_2;
} wmi_rtt_oem_cap_rsp_event;

typedef struct
{
    uint32_t tlv_header;
    uint32_t version;
    uint32_t revision;
} wmi_rtt_oem_get_channel_info_req_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t mhz;
    uint32_t band_center_freq1;
    uint32_t band_center_freq2;
    uint32_t info;
    uint32_t reg_info_1;
    uint32_t reg_info_2;
} wmi_rtt_oem_channel_info;

typedef struct
{
    uint32_t tlv_header;
    uint32_t version;
    uint32_t revision;
} wmi_rtt_oem_get_channel_info_rsp_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t version;
    uint32_t revision;
    uint8_t  mode;
    uint32_t duration;
    wmi_rtt_oem_channel_info channel_info;
} wmi_rtt_oem_set_responder_mode_req_head;

typedef struct
{
    uint32_t tlv_header;
    uint32_t version;
    uint32_t revision;
} wmi_rtt_oem_set_responder_mode_rsp_head;

#define WMIRTT_TLV_GET_TLVTAG(tlv_header)  ((uint32_t)((tlv_header)>>16))

#define LOWI_CLEAR_11MC_BIT 0xfe

#define WMI_RTT_CAP_ONESIDED_RTT               (0x01)
#define WMI_RTT_CAP_TWOSIDED_RTT               (0x02)
#define WMI_RTT_CAP_NULL                       (0x01)
#define WMI_RTT_CAP_QOS_NULL                   (0x02)
#define WMI_RTT_CAP_TMR                        (0x04)
#define WMI_RTT_CAP_FTMR                       (0x08)
#define WMI_RTT_CAP_RTS                        (0x10)
#define WMI_RTT_CAP_20M                        (0x0)
#define WMI_RTT_CAP_40M                        (0x01)
#define WMI_RTT_CAP_80M                        (0x02)
#define WMI_RTT_CAP_160M                       (0x03)
#define WMI_RTT_CAP_LEGACY                     (0x01)
#define WMI_RTT_CAP_HT                         (0x02)
#define WMI_RTT_CAP_VHT                        (0x04)
#define WMI_RTT_CAP_REPORT_PER_FRAME_CFR       (0x01)
#define WMI_RTT_CAP_REPORT_PER_FRAME_NO_CFR    (0x02)
#define WMI_RTT_CAP_REPORT_AGGREGATE_NO_CFR    (0x04)
#define WMI_RTT_CAP_REPORT_PER_BURST_NO_CFR    (0x08)
#define WMI_RTT_CAP_NO_FAC                     (0x0)
#define WMI_RTT_CAP_SW_FAC                     (0x01)
#define WMI_RTT_CAP_HW_FAC                     (0x02)

#define WMI_RTT_CAP_VER_S 0
#define WMI_RTT_CAP_VER (0xff <<  WMI_RTT_CAP_VER_S)
#define WMI_RTT_CAP_VER_GET(x) WMI_F_MS(x, WMI_RTT_CAP_VER)
#define WMI_RTT_CAP_VER_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_VER)

#define WMI_RTT_CAP_FRAME_S 8
#define WMI_RTT_CAP_FRAME (0xff <<  WMI_RTT_CAP_FRAME_S)
#define WMI_RTT_CAP_FRAME_GET(x) WMI_F_MS(x, WMI_RTT_CAP_FRAME)
#define WMI_RTT_CAP_FRAME_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_FRAME)

#define WMI_RTT_CAP_MAX_DES_NUM_S 16
#define WMI_RTT_CAP_MAX_DES_NUM (0xff <<  WMI_RTT_CAP_MAX_DES_NUM_S)
#define WMI_RTT_CAP_MAX_DES_NUM_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MAX_DES_NUM)
#define WMI_RTT_CAP_MAX_DES_NUM_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MAX_DES_NUM)

#define WMI_RTT_CAP_MAX_MEAS_NUM_S 24
#define WMI_RTT_CAP_MAX_MEAS_NUM (0xff <<  WMI_RTT_CAP_MAX_MEAS_NUM_S)
#define WMI_RTT_CAP_MAX_MEAS_NUM_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MAX_MEAS_NUM)
#define WMI_RTT_CAP_MAX_MEAS_NUM_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MAX_MEAS_NUM)

#define WMI_RTT_CAP_MAX_CHAN_NUM_S 0
#define WMI_RTT_CAP_MAX_CHAN_NUM (0xff <<  WMI_RTT_CAP_MAX_CHAN_NUM_S)
#define WMI_RTT_CAP_MAX_CHAN_NUM_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MAX_CHAN_NUM)
#define WMI_RTT_CAP_MAX_CHAN_NUM_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MAX_CHAN_NUM)

#define WMI_RTT_CAP_MAX_BW_S 8
#define WMI_RTT_CAP_MAX_BW (0xff <<  WMI_RTT_CAP_MAX_BW_S)
#define WMI_RTT_CAP_MAX_BW_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MAX_BW)
#define WMI_RTT_CAP_MAX_BW_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MAX_BW)

#define WMI_RTT_CAP_PREAMBLE_S 16
#define WMI_RTT_CAP_PREAMBLE (0xff <<  WMI_RTT_CAP_PREAMBLE_S)
#define WMI_RTT_CAP_PREAMBLE_GET(x) WMI_F_MS(x, WMI_RTT_CAP_PREAMBLE)
#define WMI_RTT_CAP_PREAMBLE_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_PREAMBLE)

#define WMI_RTT_CAP_REPORT_TYPE_S 24
#define WMI_RTT_CAP_REPORT_TYPE (0xff <<  WMI_RTT_CAP_REPORT_TYPE_S)
#define WMI_RTT_CAP_REPORT_TYPE_GET(x) WMI_F_MS(x, WMI_RTT_CAP_REPORT_TYPE)
#define WMI_RTT_CAP_REPORT_TYPE_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_REPORT_TYPE)

#define WMI_RTT_CAP_MAX_CHAIN_MASK_S 0
#define WMI_RTT_CAP_MAX_CHAIN_MASK (0xff <<  WMI_RTT_CAP_MAX_CHAIN_MASK_S)
#define WMI_RTT_CAP_MAX_CHAIN_MASK_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MAX_CHAIN_MASK)
#define WMI_RTT_CAP_MAX_CHAIN_MASK_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MAX_CHAIN_MASK)

#define WMI_RTT_CAP_FAC_S 8
#define WMI_RTT_CAP_FAC (0xff <<  WMI_RTT_CAP_FAC_S)
#define WMI_RTT_CAP_FAC_GET(x) WMI_F_MS(x, WMI_RTT_CAP_FAC)
#define WMI_RTT_CAP_FAC_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_FAC)

#define WMI_RTT_CAP_RADIO_NUM_S 16
#define WMI_RTT_CAP_RADIO_NUM (0xff <<  WMI_RTT_CAP_RADIO_NUM_S)
#define WMI_RTT_CAP_RADIO_NUM_GET(x) WMI_F_MS(x, WMI_RTT_CAP_RADIO_NUM)
#define WMI_RTT_CAP_RADIO_NUM_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_RADIO_NUM)

#define WMI_RTT_CAP_MULTIBURST_SUPPORT_S 25
#define WMI_RTT_CAP_MULTIBURST_SUPPORT (0x1 <<  WMI_RTT_CAP_MULTIBURST_SUPPORT_S)
#define WMI_RTT_CAP_MULTIBURST_SUPPORT_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MULTIBURST_SUPPORT)
#define WMI_RTT_CAP_MULTIBURST_SUPPORT_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MULTIBURST_SUPPORT)

#define WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS_S 26
#define WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS (0xf <<  WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS_S)
#define WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS_GET(x) WMI_F_MS(x, WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS)
#define WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS_SET(x,y)  WMI_F_RMW(x,y, WMI_RTT_CAP_MAX_MULTIBURST_SESSIONS)

#define WMIRTT_TLV_GET_TLVLEN(tlv_header)  ((uint32_t)((tlv_header) & 0x0000FFFF))

typedef struct
{
    uint8_t tag;
    uint8_t idx;
} tagIdxInfo;

typedef struct
{
    uint8_t  tag;
    uint32_t tlvSize;
    uint8_t  subtype;
    uint8_t  numOtherTags;
    const char *tlvStr;
    tagIdxInfo *otherTags;
} measMsgInfo;

tagIdxInfo otherTagsPerPeerEvtHdrTlv[2] =
{
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info, 6},
    {WMIRTT_TLV_TAG_STRUC_loop_end, 8}
};

tagIdxInfo otherTagsPerFrameInfoTlv[2] =
{
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info, 6},
    {WMIRTT_TLV_TAG_STRUC_loop_end, 7}
};

tagIdxInfo otherTagsMeasLoopEndTlv[1] =
{
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info, 6}
};

tagIdxInfo otherTagsPeerLoopEndTlv[1] =
{
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_peer_event_hdr, 3},
};

#define CHANNEL_MSG_ARR_SZ 3
measMsgInfo const channelMsgArr[CHANNEL_MSG_ARR_SZ] =
{ // idx 0
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head,
    sizeof(wmi_rtt_oem_rsp_head),
    (uint8_t)RTT_MSG_SUBTYPE_GET_CHANNEL_INFO_RSP,
    0, "wmi_rtt_oem_rsp_head", NULL},

    // idx 1
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_get_channel_info_rsp_head,
    sizeof(wmi_rtt_oem_get_channel_info_req_head), 0,
    0, "wmi_rtt_oem_get_channel_info_rsp_head", NULL},

    // idx 2
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_channel_info,
    sizeof(wmi_rtt_oem_channel_info), 0,
    0, "wmi_rtt_oem_channel_info", NULL}
};

#define RESPONDER_CHANNEL_MSG_ARR_SZ 3
measMsgInfo const ResponderchannelMsgArr[RESPONDER_CHANNEL_MSG_ARR_SZ] =
{ // idx 0
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head,
    sizeof(wmi_rtt_oem_rsp_head),
    (uint8_t)RTT_MSG_SUBTYPE_CFG_RESPONDER_MODE_RSP,
    0, "wmi_rtt_oem_rsp_head", NULL},

    // idx 1
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_set_responder_mode_rsp_head,
    sizeof(wmi_rtt_oem_set_responder_mode_rsp_head), 0,
    0, "wmi_rtt_oem_set_responder_mode_rsp_head", NULL},

    // idx 2
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_channel_info,
    sizeof(wmi_rtt_oem_channel_info), 0,
    0, "wmi_rtt_oem_channel_info", NULL}
};

#define CAPS_MSG_ARR_SZ 3
measMsgInfo const capsMsgArr[CAPS_MSG_ARR_SZ] =
{ // idx 0
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head,
    sizeof(wmi_rtt_oem_rsp_head),
    (uint8_t)RTT_MSG_SUBTYPE_CAPABILITY_RSP,
    0, "wmi_rtt_oem_rsp_head", NULL},

    // idx 1
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_rsp_head,
    sizeof(wmi_rtt_oem_cap_rsp_head), 0,
    0, "wmi_rtt_oem_cap_rsp_head", NULL},

    // idx 2
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_rsp_event,
    sizeof(wmi_rtt_oem_cap_rsp_event), 0,
    0, "wmi_rtt_oem_cap_rsp_event", NULL}
};

#define ERR_MSG_ARR_SZ 2
measMsgInfo const errMsgArr[ERR_MSG_ARR_SZ] =
{ // idx 0
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head,
    sizeof(wmi_rtt_oem_rsp_head),
    (uint8_t)RTT_MSG_SUBTYPE_ERROR_REPORT_RSP,
    0, "wmi_rtt_oem_rsp_head", NULL},

    // idx 1
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measrsp_head,
    sizeof(wmi_rtt_oem_measrsp_head), 0,
    0, "wmi_rtt_oem_measrsp_head", NULL}
};

#define MEAS_MSG_ARR_SZ 9
measMsgInfo const measMsgArr[MEAS_MSG_ARR_SZ] =
{ // idx 0
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head,
    sizeof(wmi_rtt_oem_rsp_head),
    (uint8_t)RTT_MSG_SUBTYPE_MEASUREMENT_RSP,
    0, "wmi_rtt_oem_rsp_head", NULL},

    // idx 1
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measrsp_head,
    sizeof(wmi_rtt_oem_measrsp_head), 0,
    0, "wmi_rtt_oem_measrsp_head", NULL},

    // idx 2
    {WMIRTT_TLV_TAG_STRUC_loop_start,
    RTT_TLV_HDR_SIZE,0,
    0, "loop_start", NULL},

    // idx 3
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_peer_event_hdr,
    sizeof(wmi_rtt_oem_per_peer_event_hdr), 0,
    2, "wmi_rtt_oem_per_peer_event_hdr", otherTagsPerPeerEvtHdrTlv},

    // idx 4
    {WMIRTT_TLV_TAG_ARRAY_UINT8,
    RTT_TLV_HDR_SIZE, 0,
    0, "WMIRTT_TLV_TAG_ARRAY_UINT8", NULL},

    // idx 5
    {WMIRTT_TLV_TAG_STRUC_loop_start,
    RTT_TLV_HDR_SIZE, 0,
    0, "loop_start", NULL},

    // idx 6
    {WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info,
    sizeof(wmi_rtt_oem_per_frame_info), 0,
    2, "wmi_rtt_oem_per_frame_info", otherTagsPerFrameInfoTlv},

    // idx 7
    {WMIRTT_TLV_TAG_STRUC_loop_end,
    RTT_TLV_HDR_SIZE, 0,
    1, "loop_end", otherTagsMeasLoopEndTlv},

    // idx 8
    {WMIRTT_TLV_TAG_STRUC_loop_end,
    RTT_TLV_HDR_SIZE, 0,
    1, "loop_end", otherTagsPeerLoopEndTlv}
};

unsigned int if_nametoindex(const char *ifname);

typedef struct
{
    int nl_sock_fd;
    pthread_t rxNlThread;
    uint8_t waitingRsp;
    uint8_t reqType;
    uint8_t retryNum;
    uint8_t scanChannelNum;
    uint16_t bandCenterFreqForty;
    uint16_t bandCenterFreqEighty;
    uint8_t rttPhyMode;
    uint8_t ht20Supported;
    uint8_t ht40Supported;
    uint8_t vht20Supported;
    uint8_t vht40Supported;
    uint8_t vht80Supported;
    uint8_t peer11MCSupported;
    uint32_t peer11MCCap;
    uint8_t scanPreamble;
    uint8_t scanBandWidth;
    uint8_t burstNum;
    uint8_t rttFrameType;
    uint8_t scanMacAddr[6];
    uint8_t isQTIPeer;
    char ifIndex[10];
    uint8_t waitingForPeerInfo;
    uint8_t vDevId;
    uint16_t rtsCtsTag;
    uint16_t reqId;
    int num_acks_for_dump;
    int num_finishes_for_dump;
    int genl_integrity_check_fail;
    uint8_t rxChainsUsed;
    uint8_t mPeerLs;
    uint8_t mMeasLs;
    RomeRttCapabilities rttRspCap;
    struct nl80211_state nlstate;
    VDevInfo vDevInfo;
    int scanRetryTimes;
    ChannelInfo channelInfoArray[MAX_CHANNEL_ID];
    uint8_t NlBuf[MAX_NLMSG_LEN];
    uint8_t rxBuff[MAX_NLMSG_LEN];
}rtt_config_t;
static rtt_config_t rttConfig;

uint8_t getPreamble(uint8_t preamble)
{
    switch (preamble)
    {
        case RTT_PREAMBLE_LEGACY:
            return ROME_PREAMBLE_LEGACY;
        case RTT_PREAMBLE_HT:
            return ROME_PREAMBLE_HT;
        case RTT_PREAMBLE_VHT:
            return ROME_PREAMBLE_VHT;
        default:
            return ROME_PREAMBLE_LEGACY;
    }
}

uint8_t * allocAniMsgHdr(uint32_t aniMsgLen, uint32_t aniHdrLen)
{
    uint8_t *aniMsg = NULL;
    aniMsg = (uint8_t *)malloc(aniHdrLen + aniMsgLen);
    if (aniMsg != NULL)
    {
        memset(aniMsg, 0, sizeof(aniHdrLen + aniMsgLen));
        tAniMsgHdr *pHdr = (tAniMsgHdr *)aniMsg;
        pHdr->type       = ANI_MSG_OEM_DATA_REQ;
        pHdr->length     = aniMsgLen;
    }
    return aniMsg;
}

uint32_t freqToChannel(uint32_t freq)
{
    switch (freq)
    {
        default:
            return 0;
    }
}

uint32_t channelToFreq (uint32_t channel)
{
    switch (channel)
    {
        /*2.4 GHz Band*/
        case 1:  return 2412;
        case 2:  return 2417;
        case 3:  return 2422;
        case 4:  return 2427;
        case 5:  return 2432;
        case 6:  return 2437;
        case 7:  return 2442;
        case 8:  return 2447;
        case 9:  return 2452;
        case 10: return 2457;
        case 11: return 2462;
        case 12: return 2467;
        case 13: return 2472;
        case 14: return 2484;
        /*5 GHz Band*/
        case 34:  return 5170;
        case 36:  return 5180;
        case 38:  return 5190;
        case 40:  return 5200;
        case 42:  return 5210;
        case 44:  return 5220;
        case 46:  return 5230;
        case 48:  return 5240;
        case 52:  return 5260;
        case 56:  return 5280;
        case 60:  return 5300;
        case 64:  return 5320;
        case 100: return 5500;
        case 104: return 5520;
        case 108: return 5540;
        case 112: return 5560;
        case 116: return 5580;
        case 120: return 5600;
        case 124: return 5620;
        case 128: return 5640;
        case 132: return 5660;
        case 136: return 5680;
        case 140: return 5700;
        case 149: return 5745;
        case 153: return 5765;
        case 157: return 5785;
        case 161: return 5805;
        case 165: return 5825;
        /** Other than 2.4 / 5 Ghz band */
        default:
            printf ("channelToFreq , Invalid Channel");
        return 0;
    }
}

uint32_t getChannelFreq (uint32_t channel)
{
    uint32_t freqBase = 2412;
    if (channel == 14)
    {
        printf("Freq = %u",2484);
        return 2484;
    }
    if (channel >= 1 && channel <= 13)
    {
        freqBase = 2412;
        channel = channel - 1;
    }
    else if (channel >= 34 && channel <= 64)
    {
        freqBase = 5170;
        channel = channel - 34;
    }
    else if (channel >= 100 && channel <= 165)
    {
        freqBase = 5500;
        channel = channel - 100;
    }
    else
    {
        printf("Invalid channel = %d",channel);
        return 0;
    }
    if(debug_enable)
    {
        printf("Freq = %u",(freqBase + (channel * 5)));
    }
    return (freqBase + (channel * 5));
}

void  getChannelsOrFreqs(eBand band, int *chan_freq, uint8_t *num_channels, bool freq)
{
    uint8_t ii;
    switch (band)
    {
        case TWO_POINT_FOUR_GHZ:
        {
            *num_channels = sizeof(channelArr_2_4_ghz) / sizeof(channelArr_2_4_ghz[0]);
            if (NULL != chan_freq)
            {
                for (ii = 0; ii < *num_channels; ++ii)
                {
                    if (true == freq)
                    {
                        *(chan_freq + ii) = freqArr_2_4_ghz[ii];
                    }
                    else
                    {
                        *(chan_freq + ii) = channelArr_2_4_ghz[ii];
                    }
                }
           }
           break;
        }
        case FIVE_GHZ:
        {
            *num_channels = sizeof(channelArr_5_ghz) / sizeof(channelArr_5_ghz[0]);
            if (NULL != chan_freq)
            {
                for (ii = 0; ii < *num_channels; ++ii)
                {
                    if (true == freq)
                    {
                        *(chan_freq + ii) = freqArr_5_ghz[ii];
                    }
                    else
                    {
                        *(chan_freq + ii) = channelArr_5_ghz[ii];
                    }
                 }
             }
             break;
        }
        default:
        // All
        {
            *num_channels = sizeof(channelArr_2_4_ghz) / sizeof(channelArr_2_4_ghz[0]);
            *num_channels += sizeof(channelArr_5_ghz) / sizeof(channelArr_5_ghz[0]);
            if (NULL != chan_freq)
            {
                // First copy the 2.4 Ghz freq / channels
                uint32_t index = 0;
                for (; index < (sizeof(channelArr_2_4_ghz) / sizeof(channelArr_2_4_ghz[0]));
                        ++index)
                {
                    if (true == freq)
                    {
                        *(chan_freq + index) = freqArr_2_4_ghz[index];
                    }
                    else
                    {
                        *(chan_freq + index) = channelArr_2_4_ghz[index];
                    }
                }
                // Copy the 5 Ghz freq / channels
                for (ii = 0;
                        ii < (sizeof(channelArr_5_ghz) / sizeof(channelArr_5_ghz[0])); ++ii)
                {
                    if (true == freq)
                    {
                        *(chan_freq + index + ii) = freqArr_5_ghz[ii];
                    }
                    else
                    {
                        *(chan_freq + index + ii) = channelArr_5_ghz[ii];
                    }
                }
            }
            break;
        }
    }
}


static int send_nl_msg(int fd,uint8_t *data,uint32_t len)
{
    struct sockaddr_nl d_nladdr;
    struct msghdr msg ;
    struct iovec iov;
    struct nlmsghdr *nlh=NULL;

    nlh = (struct nlmsghdr *)malloc(NLMSG_SPACE(len));
    if(!nlh) /* Memory allocation failed */
    {
        return -1;
    }

    /* destination address */
    memset(&d_nladdr, 0 ,sizeof(d_nladdr));
    d_nladdr.nl_family= AF_NETLINK;
    d_nladdr.nl_pad=0;
    d_nladdr.nl_pid = 0; /* destined to kernel */

    /* Fill the netlink message header */
    memset(nlh , 0 , len);
    memset(&iov, 0, sizeof(struct iovec));

    nlh->nlmsg_len = NLMSG_LENGTH(len);
    nlh->nlmsg_type = WLAN_NL_MSG_OEM;
    nlh->nlmsg_flags = NLM_F_REQUEST;
    nlh->nlmsg_pid = getpid();

    memcpy(NLMSG_DATA(nlh), data,len );

    if(sendmsg(fd, &msg, 0) < 0)
    {
        printf("Failed to send message over NL\n");
        free(nlh);
        return -1;
    }
    else
    {
        rttConfig.waitingRsp = 1;
        if(debug_enable)
        {
            printf("Successfully sent message over NL\n");
        }
        free(nlh);
        return 0;
    }
}


int sendRegReq()
{
    uint8_t appRegSignature[] = APP_REG_SIGNATURE;
    printf("\nenter sendRegReq()\n");
    /* Alocate Space for ANI Message (Header + Body) */
    uint8_t *aniMessage = (uint8_t *)malloc(sizeof(tAniMsgHdr) + APP_REG_SIGNATURE_LENGTH);
    if (!aniMessage)
    {
        printf("Failed to Allocate %u bytes of Memory for reg req\n",(uint32_t)(sizeof(tAniMsgHdr) + APP_REG_SIGNATURE_LENGTH));
        return -1;
    }

    /* Fill the ANI Header */
    tAniMsgHdr *aniMsgHeader = (tAniMsgHdr *)aniMessage;
    aniMsgHeader->type = ANI_MSG_APP_REG_REQ;
    aniMsgHeader->length = APP_REG_SIGNATURE_LENGTH;

    /* Fill in the ANI Message Body */
    uint8_t *aniMsgBody = (uint8_t *)(aniMessage + sizeof(tAniMsgHdr));
    memcpy(aniMsgBody, appRegSignature, APP_REG_SIGNATURE_LENGTH);
    if(debug_enable)
    {
        printf("Sending reg req Message over NL...\n");
    }
    /* ANI Message over Netlink Socket */
    if (send_nl_msg(rttConfig.nl_sock_fd, aniMessage, (sizeof(tAniMsgHdr) + APP_REG_SIGNATURE_LENGTH)) < 0)
    {
        printf("NL Send reg req Failed\n");
        free(aniMessage);
        return -1;
    }

    free(aniMessage);

    return 0;
}

int sendChannelInfoReq()
{
    // ani message header length
    uint32_t aniHdrLen = sizeof(tAniMsgHdr);

    // ani message length = length of all TLVs
    uint32_t aniMsgLen = sizeof(wmi_rtt_oem_req_head) + sizeof(wmi_rtt_oem_get_channel_info_req_head);

    printf("\nenter sendChannelInfoReq()\n");
    uint8_t *aniMessage = allocAniMsgHdr(aniMsgLen, aniHdrLen);
    if (aniMessage == NULL)
    {
        return -1;
    }

    // Fill out the ANI message body with the TLVs. Message body starts after the header.
    uint8_t *aniMsgBody = (uint8_t *)(aniMessage + (uint8_t)aniHdrLen);

    // Adding the wmi_rtt_oem_req_head TLV
    wmi_rtt_oem_req_head *reqHead = (wmi_rtt_oem_req_head *)aniMsgBody;
    WMIRTT_TLV_SET_HDR(&reqHead->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_req_head,
            sizeof(wmi_rtt_oem_req_head));
    reqHead->sub_type = RTT_MSG_SUBTYPE_GET_CHANNEL_INFO_REQ;
    reqHead->req_id   = ++rttConfig.reqId;

    // Adding the wmi_rtt_oem_cap_req_head TLV
    wmi_rtt_oem_get_channel_info_req_head *channelReqHead =
    (wmi_rtt_oem_get_channel_info_req_head *)(aniMsgBody + sizeof(wmi_rtt_oem_req_head));
    WMIRTT_TLV_SET_HDR(&channelReqHead->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_get_channel_info_req_head,
            sizeof(wmi_rtt_oem_get_channel_info_req_head));
    channelReqHead->version = RTT_VER_SET_VERSION(RTT_VERSION_MAJOR, RTT_VERSION_MINOR);
    channelReqHead->revision  = RTT_REVISION;
    if(debug_enable)
    {
        printf("sendChannelInfoReq: subtype(%d) requestID(%d) aniMsgLen(%u) aniHdrLen(%u)\n",
                reqHead->sub_type,
                reqHead->req_id, aniMsgLen, aniHdrLen);
    }
    /* Send ANI Message over Netlink Socket */
    if (send_nl_msg(rttConfig.nl_sock_fd, aniMessage, (sizeof(tAniMsgHdr) + aniMsgLen)) < 0)
    {
        printf("channel info req: NL Send Failed\n");
        free(aniMessage);
        return -1;
    }
    if(debug_enable)
    {
        printf("Sent Channel Info Request to FW\n");
    }
    free(aniMessage);
    return 0;
}

int sendChannelInfoReqToCld()
{
    uint32_t i;
    uint32_t aniMsgLen;
    uint8_t *aniChIds;
    int channel_list[(sizeof(channelArr_2_4_ghz)/sizeof(channelArr_2_4_ghz[0])) +
            (sizeof(channelArr_5_ghz)/sizeof(channelArr_5_ghz[0]))];
    uint8_t channel_list_len;
    printf("\nenter sendChannelInfoReqToCld()\n");
    getChannelsOrFreqs(BAND_ALL, &channel_list[0], &channel_list_len, false);
    aniMsgLen = (uint32_t)channel_list_len;
    /* Allocate Space for ANI Message (Header + Body) */
    uint8_t *aniMessage = (uint8_t *)malloc(sizeof(tAniMsgHdr) + aniMsgLen);
    if (!aniMessage) /* Memory Allocation Failed */
    {
        return -1;
    }

    tAniMsgHdr *aniMsgHeader = (tAniMsgHdr *)aniMessage;
    aniMsgHeader->type = ANI_MSG_CHANNEL_INFO_REQ;
    aniMsgHeader->length = aniMsgLen;

    aniChIds = (uint8_t *)(aniMessage + sizeof(tAniMsgHdr));
    for (i = 0; i < aniMsgLen; i++)
    {
        aniChIds[i] = (uint8_t)(channel_list[i]);
    }
    /* Send ANI Message over Netlink Socket */
    if (send_nl_msg(rttConfig.nl_sock_fd, aniMessage, (sizeof(tAniMsgHdr) + aniMsgLen)) < 0)
    {
        printf("channel info req: NL Send Failed\n");
        free(aniMessage);
        return -1;
    }
    if(debug_enable)
    {
        printf("Sent Channel Info Request to host driver\n");
    }
    free(aniMessage);
    return 0;
}


int sendRangingCapReq()
{
    // ani message header length
    uint32_t aniHdrLen = sizeof(tAniMsgHdr);

    // ani message length = length of all TLVs
    uint32_t aniMsgLen = sizeof(wmi_rtt_oem_req_head) + sizeof(wmi_rtt_oem_cap_req_head);

    uint8_t *aniMessage = allocAniMsgHdr(aniMsgLen, aniHdrLen);
    printf("\nenter sendRangingCapReq\n");
    if (aniMessage == NULL)
    {
        printf("sendRangingCapReq: Failed to allocate memory for ANI message\n");
        return -1;
    }

    uint8_t *aniMsgBody = (uint8_t *)(aniMessage + (uint8_t)aniHdrLen);

    wmi_rtt_oem_req_head *reqHead = (wmi_rtt_oem_req_head *)aniMsgBody;
    WMIRTT_TLV_SET_HDR(&reqHead->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_req_head,
            sizeof(wmi_rtt_oem_req_head));
    reqHead->sub_type = RTT_MSG_SUBTYPE_CAPABILITY_REQ;
    reqHead->req_id   = ++rttConfig.reqId;
    reqHead->pdev_id = 0;

    // Adding the wmi_rtt_oem_cap_req_head TLV
    wmi_rtt_oem_cap_req_head *capReqHead =
            (wmi_rtt_oem_cap_req_head *)(aniMsgBody + sizeof(wmi_rtt_oem_req_head));
    WMIRTT_TLV_SET_HDR(&capReqHead->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_req_head,
            sizeof(wmi_rtt_oem_cap_req_head));
    capReqHead->version  = RTT_VER_SET_VERSION(RTT_VERSION_MAJOR, RTT_VERSION_MINOR);
    capReqHead->revision = RTT_REVISION;
    if(debug_enable)
    {
        printf("sendRangingCapReq: subtype(%d) requestID(%d) aniMsgLen(%u) aniHdrLen(%u)\n",
                reqHead->sub_type,
                reqHead->req_id, aniMsgLen, aniHdrLen);
    }
    /* Send ANI Message over Netlink Socket */
    if (send_nl_msg(rttConfig.nl_sock_fd, aniMessage, (sizeof(tAniMsgHdr) + aniMsgLen)) < 0)
    {
        printf("cap req: NL Send Failed\n");
        free(aniMessage);
        return -1;
    }

    free(aniMessage);
    return 0;
}

uint32_t setReqHeadTlv(uint8_t *msg, uint32_t reqId)
{
    wmi_rtt_oem_req_head *reqHead = (wmi_rtt_oem_req_head *)msg;
    memset((uint8_t*)reqHead,0,sizeof(wmi_rtt_oem_req_head));
    WMIRTT_TLV_SET_HDR(&reqHead->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_req_head,
            sizeof(wmi_rtt_oem_req_head));
    reqHead->sub_type = RTT_MSG_SUBTYPE_MEASUREMENT_REQ;
    reqHead->req_id   = reqId;
    reqHead->pdev_id = 0;
    if(debug_enable)
    {
        printf("setReqHeadTlv: subtype(0x%x) requestID(0x%x) pdevId(0x%x)\n",
                reqHead->sub_type,reqHead->req_id,reqHead->pdev_id);
    }
    return sizeof(wmi_rtt_oem_req_head);
}

uint32_t setMeasReqHeadTlv(uint8_t *msg, uint32_t channelCnt)
{
    wmi_rtt_oem_measreq_head *measReqHead = (wmi_rtt_oem_measreq_head *)msg;
    memset((uint8_t*)measReqHead,0,sizeof(wmi_rtt_oem_measreq_head));
    WMIRTT_TLV_SET_HDR(&measReqHead->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measreq_head,
            sizeof(wmi_rtt_oem_measreq_head));
    WMI_RTT_NUM_CHAN_SET(measReqHead->channel_cnt, channelCnt);
    return sizeof(wmi_rtt_oem_measreq_head);
}

uint32_t setLoopStartTlv(uint8_t *msg)
{
    uint32_t *tlvHdr = (uint32_t *)msg;
    memset((uint8_t*)tlvHdr,0,RTT_TLV_HDR_SIZE);
    WMIRTT_TLV_SET_HDR(&(*tlvHdr),
            WMIRTT_TLV_TAG_STRUC_loop_start,
            RTT_TLV_HDR_SIZE);
    return RTT_TLV_HDR_SIZE;
}

uint32_t setChannelInfoTlv(uint8_t *msg, wmi_channel *channelInfo)
{
    wmi_rtt_oem_channel_info *chanInfo = (wmi_rtt_oem_channel_info *)msg;
    memset((uint8_t*)chanInfo,0,sizeof(wmi_rtt_oem_channel_info));
    WMIRTT_TLV_SET_HDR(&chanInfo->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_channel_info,
            sizeof(wmi_rtt_oem_channel_info));

    if (channelInfo->band_center_freq1 == 0)
    {
        if(debug_enable)
        {
            printf("setChannelInfoTlv: band_center_freq1 = primary Frequency(%u)\n",channelInfo->mhz);
        }
        channelInfo->band_center_freq1 = channelInfo->mhz;
    }
    memcpy(&(chanInfo->mhz), channelInfo, sizeof(wmi_channel));
    return sizeof(wmi_rtt_oem_channel_info);
}

uint32_t setPerChannelInfoTlv(uint8_t *msg, uint32_t numSTA)
{
    wmi_rtt_oem_measreq_per_channel_info *perChannelInfo =
            (wmi_rtt_oem_measreq_per_channel_info *)msg;
    memset((uint8_t*)perChannelInfo,0,sizeof(wmi_rtt_oem_measreq_per_channel_info));
    WMIRTT_TLV_SET_HDR(&perChannelInfo->tlv_header,
            WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measreq_per_channel_info,
            sizeof(wmi_rtt_oem_measreq_per_channel_info));

    WMI_RTT_NUM_STA_SET(perChannelInfo->sta_num, numSTA);

    return sizeof(wmi_rtt_oem_measreq_per_channel_info);
}

uint8_t mapNodeTypeToFW(uint8_t nodeType)
{
    switch(nodeType)
    {
        case ACCESS_POINT:
        case STA_DEVICE:
            return RTT_WMI_VDEV_TYPE_STA;
        case PEER_DEVICE:
            return RTT_WMI_VDEV_TYPE_P2P_CLI;
        case NAN_DEVICE:
            return RTT_WMI_VDEV_TYPE_NAN;
        default:
            return RTT_WMI_VDEV_TYPE_STA;
    }
}

void setMeasInfoBits(wmi_rtt_oem_measreq_peer_info *peerInfo,
                            DestInfo bssidsToScan,
                            uint32_t ii,
                            uint8_t vDevType,
                            uint32_t reportType,
                            uint32_t timeoutPerTarget)
{
    WMI_RTT_VDEV_TYPE_SET(peerInfo->measure_info, vDevType);
    WMI_RTT_MEAS_NUM_SET(peerInfo->measure_info, bssidsToScan.numFrames);
    WMI_RTT_TIMEOUT_SET(peerInfo->measure_info, timeoutPerTarget);
    WMI_RTT_REPORT_TYPE_SET(peerInfo->measure_info, reportType);
    if(debug_enable)
	{
        printf("setMeasInfoBits: measurementInfo[%u](0x%x) numFrames[%u](%u)\n",
                ii, peerInfo->measure_info,
                ii, WMI_RTT_MEAS_NUM_GET(peerInfo->measure_info));
    }
}

void setMeasParams1Bits(wmi_rtt_oem_measreq_peer_info *peerInfo,
                                DestInfo bssidsToScan, uint32_t ii)
{
    WMI_RTT_ASAP_MODE_SET(peerInfo->measure_params_1, FTM_GET_ASAP(bssidsToScan.ftmParams));
    WMI_RTT_LCI_REQ_SET(peerInfo->measure_params_1, FTM_GET_LCI_REQ(bssidsToScan.ftmParams));
    WMI_RTT_LOC_CIV_REQ_SET(peerInfo->measure_params_1, FTM_GET_LOC_CIVIC_REQ(bssidsToScan.ftmParams));
    WMI_RTT_PTSF_TIMER_SET(peerInfo->measure_params_1, FTM_GET_PTSF_TIMER_NO_PREF(bssidsToScan.ftmParams));
    WMI_RTT_NUM_BURST_EXP_SET(peerInfo->measure_params_1, FTM_GET_BURSTS_EXP(bssidsToScan.ftmParams));
    WMI_RTT_BURST_DUR_SET(peerInfo->measure_params_1, FTM_GET_BURST_DUR(bssidsToScan.ftmParams));
    WMI_RTT_BURST_PERIOD_SET(peerInfo->measure_params_1, FTM_GET_BURST_PERIOD(bssidsToScan.ftmParams));
}

void setControlFlagBits(wmi_rtt_oem_measreq_peer_info *peerInfo,
                                DestInfo bssidsToScan, uint32_t ii)
{
    uint32_t txChainMask = TX_CHAIN_1;
    WMI_RTT_FRAME_TYPE_SET(peerInfo->control_flag, bssidsToScan.rttFrameType);
    if (bssidsToScan.bandwidth == BW_160MHZ)
    {
        txChainMask = (TX_CHAIN_1 | TX_CHAIN_2);
    }
    WMI_RTT_TX_CHAIN_SET(peerInfo->control_flag, txChainMask);
    WMI_RTT_RX_CHAIN_SET(peerInfo->control_flag, RX_CHAIN_1);
    WMI_RTT_QCA_PEER_SET(peerInfo->control_flag, (rttConfig.isQTIPeer ? QTI_PEER : NON_QTI_PEER));
    WMI_RTT_BW_SET(peerInfo->control_flag, bssidsToScan.bandwidth);
    WMI_RTT_PREAMBLE_SET(peerInfo->control_flag, getPreamble(bssidsToScan.preamble));

    // Pick the data rate
    if (WMI_RTT_PREAMBLE_GET(peerInfo->control_flag) == ROME_PREAMBLE_LEGACY)
    {
        WMI_RTT_MCS_SET(peerInfo->control_flag, LEGACY_6MBPS_MCS);
    }
    else
    {
        WMI_RTT_MCS_SET(peerInfo->control_flag, VHT_HT_6_5MBPS_MCS);
    }

    WMI_RTT_RETRIES_SET (peerInfo->control_flag, bssidsToScan.numFrameRetries);

    WMI_RTT_FORCE_LEGACY_ACK_SET (peerInfo->control_flag, FTM_GET_LEG_ACK_ONLY(bssidsToScan.ftmParams));
    if(debug_enable)
    {
        printf("setControlFlagBits: control_flag[%u](0x%x) bw(0x%x) pktType(0x%x) pream(0x%x) "
                "retries(%u) qtiPeer(%u) useLegAcks(%u)\n",
                ii, peerInfo->control_flag,
                bssidsToScan.bandwidth,
                bssidsToScan.rttFrameType,
                bssidsToScan.preamble,
                bssidsToScan.numFrameRetries,
                rttConfig.isQTIPeer ? QTI_PEER : NON_QTI_PEER,
                FTM_GET_LEG_ACK_ONLY(bssidsToScan.ftmParams));
    }
}

uint32_t setPeerInfoTlv(uint8_t *msg,
                              DestInfo *bssidsToScan,
                              uint32_t numBSSIDs,
                              uint32_t reportType,
                              DestInfo *spoofBssids,
                              uint32_t timeoutPerTarget)
{
    wmi_rtt_oem_measreq_peer_info *peerInfo;
    uint32_t ii;

    uint8_t* pMsg = msg;

    for(ii = 0; ii < numBSSIDs; ii++)
    {
        peerInfo = (wmi_rtt_oem_measreq_peer_info *)pMsg;
        memset((uint8_t*)peerInfo,0,sizeof(wmi_rtt_oem_measreq_peer_info));
        WMIRTT_TLV_SET_HDR(&peerInfo->tlv_header,
                WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measreq_peer_info,
                sizeof(wmi_rtt_oem_measreq_peer_info));

        setControlFlagBits(peerInfo, bssidsToScan[ii], ii);

        uint8_t vDevType = mapNodeTypeToFW(bssidsToScan[ii].vDevType);
        setMeasInfoBits(peerInfo, bssidsToScan[ii], ii, vDevType, reportType, timeoutPerTarget);

        setMeasParams1Bits(peerInfo, bssidsToScan[ii], ii);

        memcpy(peerInfo->dest_mac, &bssidsToScan[ii].mac[0], ETH_ALEN);
        memcpy(peerInfo->spoof_bssid, &spoofBssids[ii].mac[0], ETH_ALEN);

        pMsg += sizeof(wmi_rtt_oem_measreq_peer_info);
    }

    return numBSSIDs * sizeof(wmi_rtt_oem_measreq_peer_info);
}

uint32_t setLoopEndTlv(uint8_t *msg)
{
    uint32_t *tlvHdr = (uint32_t *)msg;
    memset((uint8_t*)tlvHdr,0,RTT_TLV_HDR_SIZE);
    WMIRTT_TLV_SET_HDR(&(*tlvHdr),
            WMIRTT_TLV_TAG_STRUC_loop_end,
            RTT_TLV_HDR_SIZE);
    return RTT_TLV_HDR_SIZE;
}

int verifyTlvRspHead(wmi_rtt_oem_rsp_head *pHead, WMIRTT_OEM_MSG_SUBTYPE *subtype)
{
    int retVal = -1;
    do
    {
        if ((WMIRTT_TLV_TAG_ID)WMIRTT_TLV_GET_TLVTAG(pHead->tlv_header) !=
                WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head)
        {
            printf("verifyTlvRspHead: Invalid TLV at the head of the FW msg(%u)\n",
                    (WMIRTT_TLV_TAG_ID)WMIRTT_TLV_GET_TLVTAG(pHead->tlv_header));
            break;
        }

        *subtype = (WMIRTT_OEM_MSG_SUBTYPE)WMI_RTT_SUB_TYPE_GET(pHead->sub_type);
        if(debug_enable)
        {
            printf("verifyTlvRspHead: Received subtype(%d)\n",*subtype);
        }
        retVal = 0;
    } while (0);

    return retVal;
}

RomeNlMsgType mapAniToRomeMsg(uint8_t aniMsgType)
{
    switch (aniMsgType)
    {
        case ANI_MSG_APP_REG_RSP:
            return ROME_REG_RSP_MSG;
        case ANI_MSG_CHANNEL_INFO_RSP:
            return ROME_CHANNEL_INFO_MSG;
        case ANI_MSG_OEM_ERROR:
            return ROME_CLD_ERROR_MSG;
        case ANI_MSG_PEER_STATUS_IND:
            return ROME_P2P_PEER_EVENT_MSG;
        default:
            return ROME_NL_ERROR_MSG;
    }
}

int sendRttReq(uint16_t reqId,
                   ChannelInfo  *chanInfo,
                   unsigned int numBSSIDs,
                   DestInfo *bssidsToScan,
                   DestInfo *spoofBssids,
                   unsigned int reportType)
{
    wmi_channel channelInfo = chanInfo->wmiChannelInfo;
    int retVal = -1;
    uint32_t aniHdrLen = sizeof(tAniMsgHdr);
    uint32_t aniMsgLen = sizeof(wmi_rtt_oem_req_head) +
            sizeof(wmi_rtt_oem_measreq_head) +
            sizeof(wmi_rtt_oem_channel_info) +
            RTT_TLV_HDR_SIZE + // loop start
            sizeof(wmi_rtt_oem_measreq_per_channel_info) +
            RTT_TLV_HDR_SIZE + // loop start
            numBSSIDs * sizeof(wmi_rtt_oem_measreq_peer_info) +
            RTT_TLV_HDR_SIZE + // loop end
            RTT_TLV_HDR_SIZE;  // loop end

    uint8_t *aniMessage = allocAniMsgHdr(aniMsgLen, aniHdrLen);
    if (aniMessage == NULL)
    {
        printf("sendRttReq: Failed to allocate memory for ANI message\n");
        return -1;
    }

    uint8_t *aniMsgBody = (uint8_t *)(aniMessage + aniHdrLen);
    uint8_t *nextTlv    = aniMsgBody;

    // Add the wmi_rtt_oem_req_head TLV and advance the pointer
    nextTlv += setReqHeadTlv(nextTlv, reqId);

    // Add the wmi_rtt_oem_measreq_head TLV and advance the pointer
    // Note: only one channel allowed for now
    nextTlv += setMeasReqHeadTlv(nextTlv, 1);

    // Add the loop start TLV header here
    nextTlv += setLoopStartTlv(nextTlv);

    // Add the wmi_rtt_oem_channel_info TLV and advance the pointer
    nextTlv += setChannelInfoTlv(nextTlv, &channelInfo);

    // Add wmi_rtt_oem_measreq_per_channel_info and advance the pointer
    // todo, add loop here so multi-channel requests can be done
    nextTlv += setPerChannelInfoTlv(nextTlv, numBSSIDs);

    // Add the loop start TLV header here
    nextTlv += setLoopStartTlv(nextTlv);

    // Add wmi_rtt_oem_measreq_peer_info TLVs and advance the pointer
    nextTlv += setPeerInfoTlv(nextTlv, bssidsToScan, numBSSIDs,
            reportType, spoofBssids,
            RTT_TIMEOUT_PER_TARGET);

    // Add the loop end TLV header here
    nextTlv += setLoopEndTlv(nextTlv);

    // Add the loop end TLV header here
    nextTlv += setLoopEndTlv(nextTlv);

    if(debug_enable)
    {
        // This info is the same for all STAs, print once here
        uint32_t phyMode = 0;
        phyMode  = channelInfo.info & ~(PHY_MODE_MASK);
        printf("sendRttReq: PHY Mode(0x%x) timeoutPerTarget(0x%x) reportType(0x%x)\n",
                phyMode, RTT_TIMEOUT_PER_TARGET,
                (uint8_t)reportType);
    }

    /* ANI Message over Netlink Socket */
    if (send_nl_msg(rttConfig.nl_sock_fd, aniMessage, aniHdrLen + aniMsgLen) < 0)
    {
        printf("sendRttReq: NL Send Failed\n");
        free(aniMessage);
        return retVal;
    }

    free(aniMessage);
    retVal = 0;
    return retVal;/* ANI Message over Netlink Socket */
}

eBand freqToBand(uint32_t freq)
{
    if (2412 <= freq && 2484 >= freq)
    {
        return TWO_POINT_FOUR_GHZ;
    }
    else if (5170 <= freq && 5825 >= freq)
    {
        return FIVE_GHZ;
    }
    return BAND_ALL;
}

void setRttScanBssidPhyInfo(ChannelInfo *chanInfo,DestInfo *bssidsToScan)
{
    chanInfo->wmiChannelInfo.info &= PHY_MODE_MASK;
    if(IS_2G_CHANNEL(rttConfig.scanChannelNum))
    {
        if(rttConfig.scanPreamble == RTT_PREAMBLE_VHT)
        {
            if(rttConfig.vht20Supported)
            {
                bssidsToScan->preamble = RTT_PREAMBLE_VHT;
                if(rttConfig.scanBandWidth == BW_80MHZ || rttConfig.scanBandWidth == BW_40MHZ)
                {
                    if(rttConfig.vht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT40_2G;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT20_2G;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_20MHZ)
                {
                    bssidsToScan->bandwidth = BW_20MHZ;
                    chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT20_2G;
                    chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                }
            }
            else if(rttConfig.ht20Supported)
            {
                bssidsToScan->preamble = RTT_PREAMBLE_HT;
                if(rttConfig.scanBandWidth == BW_80MHZ || rttConfig.scanBandWidth == BW_40MHZ)
                {
                    if(rttConfig.ht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NG_HT40;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NG_HT20;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_20MHZ)
                {
                    bssidsToScan->bandwidth = BW_20MHZ;
                    chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NG_HT20;
                    chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                }
            }
            else
            {
                bssidsToScan->preamble = RTT_PREAMBLE_LEGACY;
                bssidsToScan->bandwidth = BW_20MHZ;
                chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11G;
                chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
            }
        }
        else if(rttConfig.scanPreamble == RTT_PREAMBLE_HT)
        {
            if(rttConfig.ht20Supported)
            {
                bssidsToScan->preamble = RTT_PREAMBLE_HT;
                if(rttConfig.scanBandWidth == BW_80MHZ || rttConfig.scanBandWidth == BW_40MHZ)
                {
                    if(rttConfig.ht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NG_HT40;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NG_HT20;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_20MHZ)
                {
                    bssidsToScan->bandwidth = BW_20MHZ;
                    chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NG_HT20;
                    chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                }
            }
            else
            {
                bssidsToScan->preamble = RTT_PREAMBLE_LEGACY;
                bssidsToScan->bandwidth = BW_20MHZ;
                chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11G;
                chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
            }
        }
        else
        {
            bssidsToScan->preamble = RTT_PREAMBLE_LEGACY;
            bssidsToScan->bandwidth = BW_20MHZ;
            chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11G;
            chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
        }
    }
    else
    {
        if(rttConfig.scanPreamble == RTT_PREAMBLE_VHT)
        {
            if(rttConfig.vht20Supported)
            {
                bssidsToScan->preamble = RTT_PREAMBLE_VHT;
                if(rttConfig.scanBandWidth == BW_80MHZ)
                {
                    if(rttConfig.vht80Supported)
                    {
                        bssidsToScan->bandwidth = BW_80MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT80;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqEighty;
                    }
                    else if(rttConfig.vht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT40;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT20;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_40MHZ)
                {
                    if(rttConfig.vht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT40;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT20;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_20MHZ)
                {
                    bssidsToScan->bandwidth = BW_20MHZ;
                    chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11AC_VHT20;
                    chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                }
            }
            else if(rttConfig.ht20Supported)
            {
                bssidsToScan->preamble = RTT_PREAMBLE_HT;
                if(rttConfig.scanBandWidth == BW_80MHZ || rttConfig.scanBandWidth == BW_40MHZ)
                {
                    if(rttConfig.ht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NA_HT40;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NA_HT20;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_20MHZ)
                {
                    bssidsToScan->bandwidth = BW_20MHZ;
                    chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NA_HT20;
                    chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                }
            }
            else
            {
                bssidsToScan->preamble = RTT_PREAMBLE_LEGACY;
                bssidsToScan->bandwidth = BW_20MHZ;
                chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11A;
                chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
            }
        }
        else if(rttConfig.scanPreamble == RTT_PREAMBLE_HT)
        {
            if(rttConfig.ht20Supported)
            {
                bssidsToScan->preamble = RTT_PREAMBLE_HT;
                if(rttConfig.scanBandWidth == BW_80MHZ || rttConfig.scanBandWidth == BW_40MHZ)
                {
                    if(rttConfig.ht40Supported)
                    {
                        bssidsToScan->bandwidth = BW_40MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NA_HT40;
                        chanInfo->wmiChannelInfo.band_center_freq1 = rttConfig.bandCenterFreqForty;
                    }
                    else
                    {
                        bssidsToScan->bandwidth = BW_20MHZ;
                        chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NA_HT20;
                        chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                    }
                }
                else if(rttConfig.scanBandWidth == BW_20MHZ)
                {
                    bssidsToScan->bandwidth = BW_20MHZ;
                    chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11NA_HT20;
                    chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
                }
            }
            else
            {
                bssidsToScan->preamble = RTT_PREAMBLE_LEGACY;
                bssidsToScan->bandwidth = BW_20MHZ;
                chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11A;
                chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
            }
        }
        else
        {
            bssidsToScan->preamble = RTT_PREAMBLE_LEGACY;
            bssidsToScan->bandwidth = BW_20MHZ;
            chanInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11A;
            chanInfo->wmiChannelInfo.band_center_freq1 = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum);
        }
    }
}

int sendRangingScanReq()
{
    int retVal = 0;
    int i;

    DestInfo   bssidsToScan[MAX_BSSIDS_TO_SCAN];
    ChannelInfo chanInfo;
    printf("\nenter sendRangingScanReq()\n");
    chanInfo = rttConfig.channelInfoArray[rttConfig.scanChannelNum - 1];
    /*bandwidth : 0: 20MHz (default), 1: 40 MHz, 2: 80 MHz, 3: 160 MHz*/
    /*premble : 0:LEG (default), 1:HT, 2:VHT*/
    setRttScanBssidPhyInfo(&chanInfo,bssidsToScan);
    /*1(RTT_MEAS_FRAME_QOSNULL): RTT1&RTT2,2(RTT_MEAS_FRAME_TMR):RTT3*/
    if(rttConfig.rttFrameType == 2 && rttConfig.peer11MCSupported)
    {
        bssidsToScan[0].rttFrameType = RTT_MEAS_FRAME_TMR;
    }
    else
    {
        bssidsToScan[0].rttFrameType = RTT_MEAS_FRAME_QOSNULL;
    }
    bssidsToScan[0].numFrames = rttConfig.burstNum; /*number of frames per burst. valid range: 2-31. 5: (default)*/
    bssidsToScan[0].numFrameRetries = 0;
    bssidsToScan[0].vDevType = ACCESS_POINT;
    bssidsToScan[0].ftmParams = 0xab001;  /*asap, burst duration 11, burst period 10*/
    bssidsToScan[0].tsfDelta  = 0;
    bssidsToScan[0].tsfValid  = false;
    for(i=0;i< WIFI_MAC_ID_SIZE;i++)  /*set ap mac address*/
    {
        bssidsToScan[0].mac[i] = rttConfig.scanMacAddr[i];
    }
    retVal = sendRttReq(++rttConfig.rtsCtsTag,
            &chanInfo,
            1,
            bssidsToScan,
            bssidsToScan,
            RTT_AGGREGATE_REPORT_NON_CFR);


    return retVal;
}

static int create_nl_sock()
{
    int nl_sock_fd;
    int on = 1;
    int return_status;
    struct sockaddr_nl src_addr;

    nl_sock_fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);

    if( nl_sock_fd < 0 )
    {
        printf("create_nl_sock: Failed to create Socket err\n");
        return nl_sock_fd;
    }
    else
    {
        if(debug_enable)
        {
            printf("create_nl_sock: Succeeded in creating Socket\n");
        }
    }

    memset(&src_addr, 0, sizeof(src_addr));

    src_addr.nl_family = PF_NETLINK;
    src_addr.nl_pid = getpid();  /* self pid */
    /* interested in group 1<<0 */
    src_addr.nl_groups = 0;

    return_status = setsockopt(nl_sock_fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    if( return_status < 0 )
    {
        printf("create_nl_sock: nl socket option failed\n");
        close(nl_sock_fd);
        return return_status;
    }
    else
    {
        if(debug_enable)
        {
            printf("create_nl_sock: Options set successfully\n");
        }
    }
    return_status = bind(nl_sock_fd, (struct sockaddr*)&src_addr, sizeof(src_addr));
    if( return_status < 0 )
    {
        printf("create_nl_sock: BIND errno\n");
        close(nl_sock_fd);
        return return_status;
    }
    else
    {
        if(debug_enable)
        {
            printf("create_nl_sock: Binding done successfully\n");
        }
    }

    return nl_sock_fd;
}

static int recv_nl_msg(int fd, uint8_t *data, uint32_t len)
{
    struct sockaddr_nl d_nladdr;
    struct msghdr msg;
    struct iovec iov;
    struct nlmsghdr *nlh = NULL;
    uint8_t *recvdata = NULL;
    int retVal = 0;

    nlh = (struct nlmsghdr *)malloc(NLMSG_SPACE(MAX_NLMSG_LEN));
    if (!nlh) /* Memory Allocation Failed */
    {
        return -1;
    }
    /* Source address */
    memset(&d_nladdr, 0, sizeof(d_nladdr));
    d_nladdr.nl_family = AF_NETLINK;
    d_nladdr.nl_pad = 0;
    d_nladdr.nl_pid = 0; /* Source from kernel */

    memset(nlh, 0, MAX_NLMSG_LEN);

    nlh->nlmsg_len = NLMSG_SPACE(MAX_NLMSG_LEN);
    nlh->nlmsg_type = WLAN_NL_MSG_OEM;
    nlh->nlmsg_flags = 0;
    nlh->nlmsg_pid = getpid();

    /*iov structure */
    iov.iov_base = (void *)nlh;
    iov.iov_len = MAX_NLMSG_LEN;
    /* msg */
    memset(&msg, 0, sizeof(msg));
    msg.msg_name = (void *)&d_nladdr;
    msg.msg_namelen = sizeof(d_nladdr);
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    if(debug_enable)
    {
        printf("Waiting for NL Msg from Driver\n");
    }
    retVal = recvmsg(fd, &msg, 0);

    if (retVal < 0)
    {
        printf("recv_nl_msg: Failed to recv message over NL\n");
    }
    else if (retVal == 0)
    {
        printf("recv_nl_msg: No pending message or peer is gone\n");
    }
    else
    {
        if(debug_enable)
        {
            printf("recv_nl_msg: Successfully recvd message over NL: retVal - %d & Msg Len - %d\n",
                    retVal, nlh->nlmsg_len);
        }
        recvdata = (uint8_t *)NLMSG_DATA(nlh);

        /* Actual lenght of data in NL Message */
        retVal = nlh->nlmsg_len - NLMSG_HDRLEN;
        if (retVal > ((int)len))
        {
            printf("recv_nl_msg: Recieved more Data than Expected!, expected: %u, got %u, drop %u\n",len, retVal, (retVal - len));
            memcpy(data, recvdata, len);
            retVal = len;
        }
        else
        {
            memcpy(data, recvdata, retVal);
        }
    }
    free(nlh);
    return retVal;
}

int recvNLMessage(RomeNlMsgType* msgType, uint8_t* data, uint32_t maxDataLen)
{
    int retVal = 0;
    OemMsgSubType oemMsgSubType = 0;
    tAniMsgHdr* aniMsgHdr = NULL;
    uint32_t recvLen = 0;
    bool validMsgType = true;
    uint8_t* localp = (uint8_t*)data;
    if(debug_enable)
    {
        printf("recvNLMessage()\n");
    }
    if (msgType == NULL || localp == NULL)
    {
        printf("recvNLMessage, Received invalid pointer for msgType or data\n");
        return -1;
    }

    memset(rttConfig.rxBuff, 0, MAX_NLMSG_LEN);
    memset(localp, 0, MAX_NLMSG_LEN);
    *msgType = ROME_MSG_MAX;

    recvLen = recv_nl_msg(rttConfig.nl_sock_fd, rttConfig.rxBuff, MAX_NLMSG_LEN);
    if (recvLen <= 0) {
        printf("recvNLMessage: NL Recv Failed\n");
        *msgType = ROME_NL_ERROR_MSG;
        return -1;
    }

    aniMsgHdr = (tAniMsgHdr*) rttConfig.rxBuff;

    if(ANI_MSG_OEM_DATA_RSP == aniMsgHdr->type)
    {
        // call the tlv handler to check the head of the tlv msg
        wmi_rtt_oem_rsp_head *pHead = (wmi_rtt_oem_rsp_head *)(rttConfig.rxBuff + sizeof(tAniMsgHdr));
        retVal = verifyTlvRspHead(pHead, &oemMsgSubType);
        if (retVal < 0)
        {
            return -1;
        }
        if(debug_enable)
        {
             printf("RomeNLRecvMessage:  received message of subtype: %d\n",oemMsgSubType);
        }
        switch (oemMsgSubType)
        {
            case RTT_MSG_SUBTYPE_CAPABILITY_RSP:
            {
                *msgType = ROME_RANGING_CAP_MSG;
                break;
            }
            case RTT_MSG_SUBTYPE_MEASUREMENT_RSP:
            {
                *msgType = ROME_RANGING_MEAS_MSG;
                break;
            }
            case RTT_MSG_SUBTYPE_ERROR_REPORT_RSP:
            {
                *msgType = ROME_RANGING_ERROR_MSG;
                break;
            }
            case RTT_MSG_SUBTYPE_GET_CHANNEL_INFO_RSP:
            {
                *msgType = ROME_RTT_CHANNEL_INFO_MSG;
                break;
            }
            case RTT_MSG_SUBTYPE_CFG_RESPONDER_MODE_RSP:
            {
                *msgType = ROME_RESPONDER_INFO_MSG;
                break;
            }
            default:
            {
                printf("recvNLMessage: Received a OEM Data message with bad subtype: %d\n",
                       oemMsgSubType);
                validMsgType = false;
                retVal = -1;
                break;
            }
        }
    }
    else
    {
        *msgType = mapAniToRomeMsg(aniMsgHdr->type);
        validMsgType = (*msgType == ROME_NL_ERROR_MSG) ? false : true;
    }

    if (validMsgType)
    {
        memcpy(localp, rttConfig.rxBuff, recvLen);
    }

    if (debug_enable) {
        printf("recvNLMessage: The Received ANI Msg Type: %u,RomeMsgType: %u, OEM Type: %u\n",
                   aniMsgHdr->type, *msgType, oemMsgSubType);
    }

    return retVal;
}

int RomeExtractRegRsp(uint8_t* data)
{
    uint8_t* aniNumVDevs;
    uint8_t* datap = (uint8_t*) data;
    uint8_t  numVDevs = 0;
    VDevMap* aniVdevInfo;
    uint8_t i;
    /* Extract Data from ANI Message Body */
    memset(&rttConfig.vDevInfo, 0, sizeof(VDevInfo));
    aniNumVDevs = (uint8_t *)(datap + sizeof(tAniMsgHdr));
    aniVdevInfo = (VDevMap*) (aniNumVDevs + 1);
    if(debug_enable)
    {
        printf("reg rsp : aniNumVDevs: %u\n", (*aniNumVDevs));
    }
    rttConfig.vDevInfo.numInterface = (*aniNumVDevs);
    for(i = 0;i < (*aniNumVDevs) ; i++)
    {
        rttConfig.vDevInfo.vDevMap[i].iFaceId = (aniVdevInfo + i)->iFaceId;
        rttConfig.vDevInfo.vDevMap[i].vDevId  = (aniVdevInfo + i)->vDevId;
    }

    numVDevs = (*aniNumVDevs);

    if(numVDevs <= 0)
    {
        printf("reg rsp : fail register in host driver\n");
        return -1;
    }
    else if(numVDevs > WLAN_HDD_MAX_DEV_MODE)
    {
        printf("Received more VDevs than expected!, expected: %u, received: %u\n",
                WLAN_HDD_MAX_DEV_MODE, numVDevs);
        numVDevs = WLAN_HDD_MAX_DEV_MODE;
    }
    if(debug_enable)
    {
        printf("Done Registering with host driver... Received %u vDevs\n", numVDevs);
    }
    /* Pick up just the STA VDev for now */
    for(i = 0; i < numVDevs; i++)
    {
        if(rttConfig.vDevInfo.vDevMap[i].iFaceId == WLAN_HDD_INFRA_STATION)
        {
            rttConfig.vDevId = rttConfig.vDevInfo.vDevMap[i].vDevId;
        }
    }
    if(debug_enable)
    {
        printf("reg rsp: sta mode use vDev Id: %d...: \n",rttConfig.vDevId);
    }
    return 0;
}

void processIfLoopStartTag(uint32_t tag)
{
    if (WMIRTT_TLV_TAG_STRUC_loop_start == tag)
    {
        if (rttConfig.mPeerLs == 0)
        {
            rttConfig.mPeerLs = 1; // peer list begins
        }
        else
        {
            rttConfig.mMeasLs = 1; // peer measurement begins
        }
    }
    if(debug_enable)
    {
        printf("processIfLoopStartTag: mMeasLs(%u) mPeerLs(%u)\n",rttConfig.mMeasLs, rttConfig.mPeerLs);
    }
}

void processIfLoopEndTag(uint32_t tag)
{
    if (WMIRTT_TLV_TAG_STRUC_loop_end == tag)
    {
        if (rttConfig.mMeasLs != 0)
        {
            rttConfig.mMeasLs = 0; // peer measurement done
            if(debug_enable)
            {
                printf("processIfLoopEndTag: mMeasLs(%u)...peer measurement done\n",rttConfig.mMeasLs);
            }
        }
        else
        {
            rttConfig.mPeerLs = 0; // peer list ends
            if(debug_enable)
            {
                printf("processIfLoopEndTag: mPeerLs(%u)...peer list ends\n",rttConfig.mPeerLs);
            }
        }
    }
}

void processIfPeerEvtHdrTag(uint32_t tag)
{
    if (WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_peer_event_hdr == tag)
    {
        // response the peer info
    }
    else
    {
        if(debug_enable)
        {
            printf("Not peer event header tag(42), receive tag(%u)\n",tag);
        }
    }
}

void processIfPerFrmInfoTag(uint32_t tag)
{
    if (WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info == tag)
    {
        //response per frame info for the specified peer
    }
    else
    {
        if(debug_enable)
        {
            printf("Not peer per frame info tag (43), receive tag(%u)\n",tag);
        }
    }
}

int checkTlvTag(uint32_t tag,
                     measMsgInfo const *msgArr,
                     uint8_t idx)
{
    int retVal = -1;
    uint32_t jj;

    do
    {
        if (msgArr[idx].tag == tag) // tag matches
        {
            printf("checkTlvTag: Processing idx(%u) received TLV: %s\n",idx, msgArr[idx].tlvStr);

            // these calls are used to figure out the number of
            // peers and number of measurements for each peer
            processIfLoopStartTag(msgArr[idx].tag);
            processIfLoopEndTag(msgArr[idx].tag);
            processIfPeerEvtHdrTag(msgArr[idx].tag);
            processIfPerFrmInfoTag(msgArr[idx].tag);
            retVal = 0;
        }
        else
        {
            // do we expect other tags?
            if (NULL == msgArr[idx].otherTags)
            {
                // there are no other expected tags after this TLV,
                printf("checkTlvTag: Processing idx(%u) No tags expected -- break(%s)\n",
                        idx, msgArr[idx].tlvStr);
                break;
            }

            for (jj = 0; jj < msgArr[idx].numOtherTags; ++jj)
            {
                if (msgArr[idx].otherTags[jj].tag == tag)
                {
                    // found a tag, return the new array index
                    retVal = msgArr[idx].otherTags[jj].idx;
                    printf("checkTlvTag: Processing idx(%u) received unexpected but valid TLV(%s), going to idx(%u)\n",
                        idx, msgArr[idx].tlvStr, msgArr[idx].otherTags[jj].idx);
                    break;
                 }
            }
        }
    } while (0);

    return retVal;
}  // checkTlvTag

int parseRttOemRspHead(uint8_t *pMsg, uint32_t lenFromFW)
{
    /*wmi_rtt_oem_rsp_head *pTlv = NULL;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_rsp_head))
    {
        pTlv = (wmi_rtt_oem_rsp_head *)pMsg;
    }*/
    return 0;
}

int parseRttOemMeasRspHead(uint8_t *pMsg, uint32_t lenFromFW)
{
    /*wmi_rtt_oem_measrsp_head *pTlv = NULL;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_measrsp_head))
    {
        pTlv = (wmi_rtt_oem_measrsp_head *)pMsg;
    }*/
    return 0;
}

int parseRttOemPerPeerEventHdr(uint8_t *pMsg, uint32_t lenFromFW)
{
    /*wmi_rtt_oem_per_peer_event_hdr *pTlv = NULL;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_per_peer_event_hdr))
    {
        pTlv = (wmi_rtt_oem_per_peer_event_hdr *)pMsg;
    }*/
    return 0;
}

int parseRttOemPerFrameInfo(uint8_t *pMsg, uint32_t lenFromFW)
{
    wmi_rtt_oem_per_frame_info *pTlv = NULL;
    int rtt = 0;
    int retVal = -1;

    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_per_frame_info))
    {
        pTlv = (wmi_rtt_oem_per_frame_info *)pMsg;
        rtt = pTlv->t4_del-pTlv->t3_del;
        rtt = (rtt >= 0)?rtt:(-rtt);
        printf("measured RTT is %d\n",rtt);
        retVal = 0;
    }
    return retVal;
}

int parseRttOemCapRspEvent(uint8_t *pMsg, uint32_t lenFromFW)
{
    wmi_rtt_oem_cap_rsp_event *pTlv = NULL;
    int retVal = -1;

    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_cap_rsp_event))
    {
        pTlv = (wmi_rtt_oem_cap_rsp_event *)pMsg;
        rttConfig.rttRspCap.rangingTypeMask = WMI_RTT_CAP_VER_GET(pTlv->support) & 0x01;
        uint8_t tmp = WMI_RTT_CAP_VER_GET(pTlv->support) & LOWI_CLEAR_11MC_BIT;
        tmp = tmp << 1;
        rttConfig.rttRspCap.rangingTypeMask         |= tmp;
        rttConfig.rttRspCap.supportedFramesMask     = WMI_RTT_CAP_FRAME_GET(pTlv->support);
        rttConfig.rttRspCap.maxDestPerReq           = WMI_RTT_CAP_MAX_DES_NUM_GET(pTlv->support);
        rttConfig.rttRspCap.maxMeasPerDest          = WMI_RTT_CAP_MAX_MEAS_NUM_GET(pTlv->support);
        rttConfig.rttRspCap.maxChannelsAllowed      = WMI_RTT_CAP_MAX_CHAN_NUM_GET(pTlv->cap);
        rttConfig.rttRspCap.maxBwAllowed            = WMI_RTT_CAP_MAX_BW_GET(pTlv->cap);
        rttConfig.rttRspCap.preambleSupportedMask   = WMI_RTT_CAP_PREAMBLE_GET(pTlv->cap);
        rttConfig.rttRspCap.reportTypeSupportedMask = WMI_RTT_CAP_REPORT_TYPE_GET(pTlv->cap);
        rttConfig.rttRspCap.maxRfChains             = WMI_RTT_CAP_MAX_CHAIN_MASK_GET(pTlv->cap_2);
        rttConfig.rttRspCap.facTypeMask             = WMI_RTT_CAP_FAC_GET(pTlv->cap_2);
        rttConfig.rttRspCap.numPhys                 = WMI_RTT_CAP_RADIO_NUM_GET(pTlv->cap_2);
        rttConfig.rttRspCap.fwMultiBurstSupport     = WMI_RTT_CAP_MULTIBURST_SUPPORT_GET(pTlv->cap_2);
        if(debug_enable)
        {
            printf("parsing capability respose wmi_rtt_oem_cap_rsp_event TLV:\n");
            printf("rangingTypeMask(%u) supportedFramesMask(%u) maxDestPerReq(%u) "
                        "maxMeasPerDest(%u) maxChannelsAllowed(%u) maxBwAllowed(%u)\n",
                        rttConfig.rttRspCap.preambleSupportedMask, rttConfig.rttRspCap.reportTypeSupportedMask,
                        rttConfig.rttRspCap.maxRfChains,rttConfig.rttRspCap.facTypeMask,
                        rttConfig.rttRspCap.numPhys, rttConfig.rttRspCap.fwMultiBurstSupport);
            printf("preambleSupportedMask(%u) reportTypeSupportedMask(%u) maxRfChains(%u) "
                        "facTypeMask(%u) numPhys(%u) fwMultiBurstSupport(%u)\n",
                        rttConfig.rttRspCap.preambleSupportedMask, rttConfig.rttRspCap.reportTypeSupportedMask,
                        rttConfig.rttRspCap.maxRfChains,rttConfig.rttRspCap.facTypeMask,
                        rttConfig.rttRspCap.numPhys, rttConfig.rttRspCap.fwMultiBurstSupport);
        }
        retVal = 0;
    }
    return retVal;
}

int parseRttOemCapRspHead(uint8_t *pMsg, uint32_t lenFromFW)
{
    /*wmi_rtt_oem_cap_rsp_head *pTlv = NULL;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_cap_rsp_head))
    {
        pTlv = (wmi_rtt_oem_cap_rsp_head *)pMsg;
    }*/
    return 0;
}

int parseRttOemGetChannelInfoRspHead(uint8_t *pMsg, uint32_t lenFromFW)
{
    /*wmi_rtt_oem_get_channel_info_rsp_head *pTlv = NULL;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_get_channel_info_rsp_head))
    {
        pTlv = (wmi_rtt_oem_get_channel_info_rsp_head *)pMsg;
    }*/
    return 0;
}

int parseRttOemSetResponderModeRspHead(uint8_t *pMsg, uint32_t lenFromFW)
{
    /*wmi_rtt_oem_set_responder_mode_rsp_head *pTlv = NULL;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_set_responder_mode_rsp_head))
    {
        pTlv = (wmi_rtt_oem_set_responder_mode_rsp_head *)pMsg;
    }*/
    return 0;
}

int parseRttOemChannelInfo(uint8_t *pMsg, uint32_t lenFromFW)
{
    wmi_rtt_oem_channel_info *pTlv = NULL;
    int retVal = -1;
    uint16_t chanId;
    ChannelInfo* channelInfo;
    if (pMsg != NULL && lenFromFW == sizeof(wmi_rtt_oem_channel_info))
    {
        pTlv = (wmi_rtt_oem_channel_info *)pMsg;
        chanId = freqToChannel(pTlv->mhz);
        if(chanId == 0)
        {
            printf("parseRttOemChannelInfo: wrong channel ID from freqToChannel(%u)\n", pTlv->mhz);
            return retVal;
        }
        channelInfo = &(rttConfig.channelInfoArray[chanId - 1]);
        channelInfo->chId = chanId;
        channelInfo->wmiChannelInfo.mhz = pTlv->mhz;
        channelInfo->wmiChannelInfo.band_center_freq1 = pTlv->band_center_freq1;
        channelInfo->wmiChannelInfo.band_center_freq2 = pTlv->band_center_freq2;
        channelInfo->wmiChannelInfo.info = pTlv->info;
        channelInfo->wmiChannelInfo.reg_info_1= pTlv->reg_info_1;
        channelInfo->wmiChannelInfo.reg_info_2= pTlv->reg_info_2;
        retVal = 0;
    }
    return retVal;
}

int generateLowiTlv(uint32_t tag, uint8_t *pMsg, uint32_t lenFromFW)
{
    int retVal = 0;
    switch (tag)
    {
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head:
            retVal = parseRttOemRspHead(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_measrsp_head:
            retVal = parseRttOemMeasRspHead(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_peer_event_hdr:
            retVal = parseRttOemPerPeerEventHdr(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_ARRAY_UINT8:
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_per_frame_info:
            retVal = parseRttOemPerFrameInfo(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_rsp_event:
            retVal = parseRttOemCapRspEvent(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_cap_rsp_head:
            retVal = parseRttOemCapRspHead(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_get_channel_info_rsp_head:
            retVal = parseRttOemGetChannelInfoRspHead(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_set_responder_mode_rsp_head:
            retVal = parseRttOemSetResponderModeRspHead(pMsg,lenFromFW);
            break;
        case WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_channel_info:
            retVal = parseRttOemChannelInfo(pMsg,lenFromFW);
            break;
        default:
            printf("generateLowiTlv: Unknown TLV tag\n");
            break;
    }

    return retVal;
} // generateLowiTlv

int processCommonTlvs(uint8_t *msg,
                              measMsgInfo const *msgArr,
                              uint8_t mMsgArrSz)
{
    int retVal  = -1;
    uint8_t *pMsg = msg;
    uint32_t tag;
    uint32_t lenFromFW;

    printf("processCommonTlvs: mMsgArrSz(%u)\n",mMsgArrSz);

    // this index keeps track of which element in msgArr[] is being processed
    uint8_t idx = 0;

    // common processing starts
    do
    {
        // get the TLV header and check the tag
        uint32_t *pTlvHdr = (uint32_t *)pMsg;
        tag = WMIRTT_TLV_GET_TLVTAG(*pTlvHdr);

        // check the expected tag
        int val = checkTlvTag(tag, msgArr, idx);
        if (val < 0)
        {
            printf("processCommonTlvs: bad TLV, stop processing tagIn(%u) "
                    "pTlvHdr: 0x%x, 0x%x, 0x%x, 0x%x idx(%u) TotalTlvs(%u)\n",
                    tag, pTlvHdr[0], pTlvHdr[1], pTlvHdr[2], pTlvHdr[3], idx, mMsgArrSz);
            break;
        }
        else if (val > 0)
        {
            // change the index to go to the appropriate entry in the array
            idx = val;
            continue; // unexpected but good TLV
        }

        lenFromFW = WMIRTT_TLV_GET_TLVLEN(*pTlvHdr);

        // generate a LOWITlv and store it in the vector
        // except for loop_start and loop_end TLVs
        if ( (WMIRTT_TLV_TAG_STRUC_loop_start != msgArr[idx].tag) &&
            (WMIRTT_TLV_TAG_STRUC_loop_end   != msgArr[idx].tag) )
        {
            if (0 != generateLowiTlv(tag, pMsg, lenFromFW))
            {
                printf("processCommonTlvs: could not generate LOWITlv idx = %u\n",idx);
                break;
            }
        }
        // advance the ptr to the next tlv
        pMsg += WMIRTT_TLV_GET_TLVLEN(*pTlvHdr);
        idx++;
    } while (idx < mMsgArrSz);

    // Check how far the index has been advanced. For success, the
    // index should have gone through all the elements in msgArr.
    if (idx == mMsgArrSz)
    {
        printf("processCommonTlvs: processed all %u TLVs successfully\n",mMsgArrSz);
        retVal = 0;
    }

    return retVal;
} // processCommonTlvs

int RttCommonProcessForRx(uint8_t* data)
{
    int retVal = -1;
    uint32_t mMsgArrSz;
    uint8_t *fwMsg = (uint8_t *)data + sizeof(tAniMsgHdr);
    wmi_rtt_oem_rsp_head *pHead = (wmi_rtt_oem_rsp_head *)fwMsg;
    if (WMIRTT_TLV_TAG_STRUC_wmi_rtt_oem_rsp_head != WMIRTT_TLV_GET_TLVTAG(pHead->tlv_header))
    {
        printf("RttCommonProcessForRx: wrong tag(%u), expected wmi_oem_rtt_rsp_head tag\n",
                WMIRTT_TLV_GET_TLVTAG(pHead->tlv_header));
        return retVal;
    }

    do
    {
        // check the expected order of the TLVs
        switch (pHead->sub_type)
        {
            case RTT_MSG_SUBTYPE_CAPABILITY_RSP:
                mMsgArrSz = sizeof(capsMsgArr)/sizeof(measMsgInfo);
                retVal = processCommonTlvs(fwMsg, capsMsgArr,mMsgArrSz);
                break;
            case RTT_MSG_SUBTYPE_ERROR_REPORT_RSP:
                mMsgArrSz = sizeof(errMsgArr)/sizeof(measMsgInfo);
                retVal = processCommonTlvs(fwMsg, errMsgArr,mMsgArrSz);
                break;
            case RTT_MSG_SUBTYPE_MEASUREMENT_RSP:
                mMsgArrSz = sizeof(measMsgArr)/sizeof(measMsgInfo);
                retVal = processCommonTlvs(fwMsg, measMsgArr,mMsgArrSz);
                break;
            case RTT_MSG_SUBTYPE_GET_CHANNEL_INFO_RSP:
                mMsgArrSz = sizeof(channelMsgArr)/sizeof(measMsgInfo);
                retVal = processCommonTlvs(fwMsg, channelMsgArr,mMsgArrSz);
                break;
            case RTT_MSG_SUBTYPE_CFG_RESPONDER_MODE_RSP:
                mMsgArrSz = sizeof(ResponderchannelMsgArr)/sizeof(measMsgInfo);
                retVal = processCommonTlvs(fwMsg, ResponderchannelMsgArr,mMsgArrSz);
                break;
            default:
                printf("RttCommonProcessForRx: Received subtype(%u)\n",
                        (WMIRTT_OEM_MSG_SUBTYPE)pHead->sub_type);
            break;
        }
    } while (0);
    return 0;
}

int RomeParseRangingMeas(uint8_t* measResp)
{
    int retVal = -1;
    retVal = RttCommonProcessForRx(measResp);
    return retVal;
}

int RomeExtractRttChannelInfo(uint8_t* chanInfo)
{
    int retVal = -1;
    retVal = RttCommonProcessForRx(chanInfo);
    return retVal;
}


int RomeExtractChannelInfo(uint8_t* data)
{
    Ani_channel_info* aniChannelInfo;
    uint32_t i;
    uint8_t* aniNumChan = NULL;
    uint8_t* datap = (uint8_t*) data;
    if (datap == NULL)
    {
        return -1;
    }
    printf("\nRomeExtractChannelInfo()\n");
    aniNumChan = (uint8_t *)(datap + sizeof(tAniMsgHdr));
    aniChannelInfo = (Ani_channel_info*) (aniNumChan+1);
    if(debug_enable)
    {
        printf("channel info rsp : aniNumChan: %u \n",(*aniNumChan));
    }
    for( i = 0;i < (*aniNumChan) ; i++ )
    {
        if (aniChannelInfo[i].chan_id > 0 && aniChannelInfo[i].chan_id <= MAX_CHANNEL_ID)
        {
            ChannelInfo* channelInfo = &(rttConfig.channelInfoArray[(aniChannelInfo[i].chan_id) - 1]);
            channelInfo->chId = (uint8_t)aniChannelInfo[i].chan_id;
            memcpy(&(channelInfo->wmiChannelInfo), &(aniChannelInfo[i].channel_info), sizeof(wmi_channel));
            /* Set default values for phy mode */
            channelInfo->wmiChannelInfo.info &= PHY_MODE_MASK;
            if (freqToBand(channelInfo->wmiChannelInfo.mhz) == TWO_POINT_FOUR_GHZ)
            {
                channelInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11G;
            }
            else
            {
                channelInfo->wmiChannelInfo.info |= ROME_PHY_MODE_11A;
            }
            if(debug_enable)
            {
                printf("Ch ID: %u\n", aniChannelInfo[i].chan_id);
                printf("MHz: %u\n", aniChannelInfo[i].channel_info.mhz);
                printf("band_center_freq1: %u, band_center_freq2: %u\n",
                        aniChannelInfo[i].channel_info.band_center_freq1,
                        aniChannelInfo[i].channel_info.band_center_freq2);
                printf("info: 0x%x, reg_info_1: 0x%x, reg_info_2: 0x%x\n",
                        aniChannelInfo[i].channel_info.info,
                        aniChannelInfo[i].channel_info.reg_info_1,
                        aniChannelInfo[i].channel_info.reg_info_2);
            }
        }
    }
    return 0;
}

int RomeExtractRangingCap(void* data, RomeRttCapabilities*   pRomeRttCapabilities)
{
    if (data == NULL)
    {
        printf("ranging cap : Received invalid pointer for message body or capabilties structure - data\n");
        return -1;
    }
    printf("RomeExtractRangingCap()");
    uint8_t* rttCap = ((uint8_t*)(data)) + sizeof(tAniMsgHdr) + sizeof(OemMsgSubType) + sizeof(uint32_t);

    memcpy(pRomeRttCapabilities, rttCap, sizeof(RomeRttCapabilities));

    pRomeRttCapabilities->rangingTypeMask |= CAP_SINGLE_SIDED_RANGING;
    pRomeRttCapabilities->rangingTypeMask |= CAP_DOUBLE_SIDED_RANGING;
    pRomeRttCapabilities->rangingTypeMask |= CAP_11MC_DOUBLE_SIDED_RANGING;

    /* Extract number of RX chains being used and store in Ranging Driver*/
    rttConfig.rxChainsUsed = 0;
    uint8_t rxChainBitMask = pRomeRttCapabilities->maxRfChains;

    /* This for loop counts the bits that are set in the chain mask and stores them*/
    for (rttConfig.rxChainsUsed = 0; rxChainBitMask; rttConfig.rxChainsUsed++)
    {
        rxChainBitMask &= rxChainBitMask - 1;
    }

    return 0;

}

int RomeExtractRttRangingCap(uint8_t* data)
{
    int retVal = -1;
    retVal = RttCommonProcessForRx(data);
    return retVal;

}

static void nl80211_cleanup(struct nl80211_state *state)
{
    nl_socket_free(state->nl_sock);
    nl_cb_put (state->s_cb);
    if (state->nl_cache)
    {
        nl_cache_free(state->nl_cache);
    }
    if (state->nl80211_id)
    {
        genl_family_put(state->nl80211_family_ptr);
    }
    state->nlInitialized = false;
}

static int ack_handler(struct nl_msg *msg, void *arg)
{
    int *err = arg;
    *err = 0;
    return NL_STOP;
}

static int finish_handler(struct nl_msg *msg, void *arg)
{
    int *ret = arg;
    *ret = 0;
    return NL_SKIP;
}

static int error_handler(struct sockaddr_nl *nla, struct nlmsgerr *err, void *arg)
{
    int *ret = arg;
    *ret = err->error;
    return NL_SKIP;
}

static int no_seq_check(struct nl_msg *msg, void *arg)
{
    return NL_OK;
}

static int wait_event(struct nl_msg *msg, void *arg)
{
    struct s_wait_event *wait = arg;
    struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
    int i;
    if (( gnlh->cmd == NL80211_CMD_GET_SCAN ) || (gnlh->cmd == NL80211_CMD_TRIGGER_SCAN))
    {
        printf("In event monitor : captured a scan request issued by some entity, ignoring this event");
    }
    if(debug_enable)
    {
        printf( "Wait done with Cmd %u\n", gnlh->cmd);
    }

    for (i = 0; i < wait->n_cmds; i++)
    {
        if (gnlh->cmd == wait->cmds[i])
        {
            wait->cmd = gnlh->cmd;
            if(debug_enable)
            {
                printf( "We are interested in this Cmd %u\n", wait->cmd);
            }
        }
    }

    if (gnlh->cmd == NL80211_CMD_FRAME)
    {
        //only care msg NL80211_CMD_NEW_SCAN_RESULTS
    }

    return NL_SKIP;
}

static int rtt_wait_on_nl_socket(struct nl_sock * sock, int timeout_val)
{
    struct timeval tv;
    fd_set read_fd_set;
    int max_fd = -1;
    int retval;

    tv.tv_sec = timeout_val;
    tv.tv_usec = 0;
    FD_ZERO(&read_fd_set);

    if (sock != NULL)
    {
        max_fd = nl_socket_get_fd(sock);
        FD_SET(max_fd, &read_fd_set);
    }

    if (timeout_val >= 0)
    {
        retval = select(max_fd+1, &read_fd_set, NULL,NULL,&tv);
    }
    else
    { // monitor forever...
        retval = select(max_fd+1, &read_fd_set, NULL,NULL,NULL);
    }

    if (retval == 0) //This means the select timed out
    {
        printf("No results from the Scan!! Timeout \n");
        retval = -1;
        return retval;
    }

    if (retval < 0) //This means the select failed with some error
    {
        printf("Fail, No results from the Scan!!\n");
    }
    return retval;
}

int do_listen_events(struct nl80211_state *state, int timeout_val)
{
    struct nl_cb *cb = nl_cb_alloc(NL_CB_DEFAULT);
    struct s_wait_event wait_ev;
    int err_code = 0, select_retval;
    #define RTT_NL_CMD_NUM 4
    static const uint32_t cmds[RTT_NL_CMD_NUM] = {
        NL80211_CMD_UNSPEC,
        NL80211_CMD_NEW_SCAN_RESULTS,
        NL80211_CMD_SCAN_ABORTED,
        NL80211_CMD_FRAME
    };
    if (!cb)
    {
        printf ( "failed to allocate netlink callbacks\n");
        return -1;
    }

    /* no sequence checking for multicast messages */
    nl_cb_set(cb, NL_CB_SEQ_CHECK, NL_CB_CUSTOM, no_seq_check, NULL);

    wait_ev.cmds = cmds;
    wait_ev.n_cmds = RTT_NL_CMD_NUM;
    wait_ev.pargs = NULL;
    nl_cb_set(cb, NL_CB_VALID, NL_CB_CUSTOM, wait_event, &wait_ev);

    wait_ev.cmd = 0;

    while (!wait_ev.cmd)
    {
        select_retval = rtt_wait_on_nl_socket(state->nl_sock, timeout_val);

        if (select_retval > 0)
        {
            err_code = nl_recvmsgs(state->nl_sock, cb);
            if(debug_enable)
            {
                printf("got messages on Netlink. Cmd %d Err %d\n",wait_ev.cmd,err_code);
            }
        }
        /*only care about cmd NL80211_CMD_NEW_SCAN_RESULTS*/
        if(wait_ev.cmd == NL80211_CMD_SCAN_ABORTED)
        {
            printf("got scan abort message so returning\n");
            wait_ev.cmd = -1;
            break;
        }

        if (wait_ev.cmd == NL80211_CMD_FRAME)
        {
            if (timeout_val != -1)
            {
                printf("Continuing to wait on Netlink socket\n");
                wait_ev.cmd = 0;
            }
            else
            {
                printf("NL80211_CMD_FRAME received.. stop waiting on Netlink socket - cmd: %u\n",
                        wait_ev.cmd);
            }
        }

        if (select_retval <= 0)
        {
            printf("One of the following events occured a) socket timeout b) other error c) shutdown message from pipe \n");
            wait_ev.cmd = select_retval;
            break;
        }
        else if (  timeout_val >= 0 &&  err_code < 0 )
        {
            wait_ev.cmd = select_retval;
            break;
        }

    }
    if(debug_enable)
    {
        printf("Returning to caller\n");
    }
    nl_cb_put(cb);
    return wait_ev.cmd;
}

int scan_family_handler(struct nl_msg *msg, void *arg)
{
    struct handler_args *grp = (struct handler_args *)arg;
    struct nlattr *tb[CTRL_ATTR_MAX + 1];
    struct genlmsghdr *gnlh = (struct genlmsghdr *)nlmsg_data(nlmsg_hdr(msg));
    struct nlattr *mcgrp;
    int rem_mcgrp;

    nla_parse(tb, CTRL_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
            genlmsg_attrlen(gnlh, 0), NULL);

    if (!tb[CTRL_ATTR_MCAST_GROUPS])
        return NL_SKIP;

    nla_for_each_nested(mcgrp, tb[CTRL_ATTR_MCAST_GROUPS], rem_mcgrp) {
        struct nlattr *tb_mcgrp[CTRL_ATTR_MCAST_GRP_MAX + 1];

        nla_parse(tb_mcgrp, CTRL_ATTR_MCAST_GRP_MAX,
                (struct nlattr *)nla_data(mcgrp), nla_len(mcgrp), NULL);

        if (!tb_mcgrp[CTRL_ATTR_MCAST_GRP_NAME] ||
                !tb_mcgrp[CTRL_ATTR_MCAST_GRP_ID])
            continue;

        if (strncmp((const char *)nla_data(tb_mcgrp[CTRL_ATTR_MCAST_GRP_NAME]),
                grp->group, nla_len(tb_mcgrp[CTRL_ATTR_MCAST_GRP_NAME])))
            continue;

        grp->id = nla_get_u32(tb_mcgrp[CTRL_ATTR_MCAST_GRP_ID]);
        break;
    }

    return NL_SKIP;
}


int nl_get_multicast_id(struct nl_sock *sock, const char *family, const char *group)
{
    struct nl_msg *msg;
    struct nl_cb *cb;
    int ret, ctrlid;
    struct handler_args grp;

    grp.group = group;
    grp.id = -1,

    msg = nlmsg_alloc();
    if (!msg)
        return -1;

    cb = nl_cb_alloc(NL_CB_DEFAULT);
    if (!cb)
    {
        ret = -1;
        goto out_fail_cb;
    }

    ctrlid = genl_ctrl_resolve(sock, "nlctrl");

    genlmsg_put(msg, 0, 0, ctrlid, 0,
            0, CTRL_CMD_GETFAMILY, 0);

    ret = -1;
    NLA_PUT_STRING(msg, CTRL_ATTR_FAMILY_NAME, family);

    ret = nl_send_auto_complete(sock, msg);
    if (ret < 0)
        goto out;

    ret = 1;

    nl_cb_err(cb, NL_CB_CUSTOM, error_handler, &ret);
    nl_cb_set(cb, NL_CB_ACK, NL_CB_CUSTOM, ack_handler, &ret);
    nl_cb_set(cb, NL_CB_VALID, NL_CB_CUSTOM, scan_family_handler, &grp);

    // Not an infinite loop
    while (ret > 0)
        nl_recvmsgs(sock, cb);

    if (ret == 0)
        ret = grp.id;

nla_put_failure:
out:
    nl_cb_put(cb);
out_fail_cb:
    nlmsg_free(msg);
    return ret;
}

int add_nl80211_membership(struct nl_sock *sock, const char *group)
{
    int mcid;
    int ret = -1;
    /* Scan multicast group */
    mcid = nl_get_multicast_id(sock, "nl80211", group);
    if (mcid >= 0)
    {
        ret = nl_socket_add_membership(sock, mcid);
    }
    return ret;
}

static int nl80211_init(struct nl80211_state *state)
{
    int err;

    if (state->nlInitialized)
    {
        printf ("NL Soclet Already initialized\n");
        return 0;
    }

    memset(state, 0, sizeof(struct nl80211_state));

    state->nlInitialized = false;
    state->s_cb = nl_cb_alloc(NL_CB_DEFAULT);
    if (!state->s_cb)
    {
        printf ("Failed to allocate memory\n");
        err = -1;
        goto out_handle_destroy;
    }

    state->nl_sock = nl_socket_alloc_cb(state->s_cb);
    if (!state->nl_sock)
    {
        printf ( "Failed to allocate netlink socket.\n");
        err = -1;
        goto out_handle_destroy;
    }

    if (genl_connect(state->nl_sock))
    {
        printf ( "Failed to connect to generic netlink.\n");
        err = -1;
        goto out_handle_destroy;
    }

    if (genl_ctrl_alloc_cache(state->nl_sock, &(state->nl_cache)))
    {
        printf ("Error in Allocating Cache\n");
        err = -1;
        goto out_handle_destroy;
    }
    state->nl80211_family_ptr = genl_ctrl_search_by_name(state->nl_cache,"nl80211");

    if(!state->nl80211_family_ptr)
    {
        printf ( "Failed to get n180211 family \n");
        err = -1;
        goto out_handle_destroy;
    }

    state->nl80211_id = genl_family_get_id(state->nl80211_family_ptr);

    if (state->nl80211_id == 0)
    {
        printf ( "nl80211 not found.\n");
        err = -1;
        goto out_handle_destroy;
    }

    if ((add_nl80211_membership(state->nl_sock, "scan") != 0) ||
        (add_nl80211_membership(state->nl_sock, "vendor") != 0))
    {
        printf("nl80211 add membership failed\n");
        err = -1;
        goto out_handle_destroy;
    }

    state->nlInitialized = true;
    if(debug_enable)
    {
        printf ("NL80211 Init Done.\n");
    }
    return 0;

out_handle_destroy:
    nl80211_cleanup(state);
    return err;
}

static int do_trigger_scan()
{
    struct nl_msg * msg;
    struct nl_msg *ssids = NULL, *freqs = NULL;
    struct nl_cb * cb;
    int idx,err;
    uint32_t scan_flags = 0;

    idx = if_nametoindex(rttConfig.ifIndex);
    if(debug_enable)
    {
        printf ( "Alloc NL Messages\n");
    }
    msg = nlmsg_alloc();
    if (!msg)
    {
        printf ( "failed to allocate netlink message\n");
        return -1;
    }

    ssids = nlmsg_alloc();
    if (!ssids)
    {
        printf ( "failed to allocate ssid space\n");
        return -1;
    }

    freqs = nlmsg_alloc();
    if (!freqs)
    {
        nlmsg_free(ssids);
        printf("failed to allocate freq space\n");
        return -1;
    }
    if(debug_enable)
    {
        printf ( "Alloc Callbacks\n");
    }
    cb = nl_cb_alloc(NL_CB_DEFAULT);
    if (!cb)
    {
        printf ( "failed to allocate netlink callbacks\n");
        err = -1;
        goto out_free_msg;
    }

    /* only add the RTT measure channel freq to get scan response asap*/
    NLA_PUT_U32(freqs, 1, channelToFreq(rttConfig.scanChannelNum));

    genlmsg_put(msg, 0, 0, rttConfig.nlstate.nl80211_id, 0,
        0, NL80211_CMD_TRIGGER_SCAN, 0);

    NLA_PUT_U32(msg, NL80211_ATTR_IFINDEX, idx);

    NLA_PUT(ssids, 1, 0, "");

    nla_put_nested(msg, NL80211_ATTR_SCAN_FREQUENCIES, freqs);

    nla_put_nested(msg, NL80211_ATTR_SCAN_SSIDS, ssids);

    /* each scan flush previous cached old entry*/
    scan_flags |= NL80211_SCAN_FLAG_FLUSH;
    nla_put_u32(msg, NL80211_ATTR_SCAN_FLAGS, scan_flags);

    /*add bssid to scan request*/
    nla_put(msg, NL80211_ATTR_MAC, ETH_ALEN, rttConfig.scanMacAddr);

    err = nl_send_auto_complete(rttConfig.nlstate.nl_sock, msg);
    if (err < 0)
    {
        goto out;
    }

    err = 1;

    nl_cb_err(cb, NL_CB_CUSTOM, error_handler, &err);
    nl_cb_set(cb, NL_CB_FINISH, NL_CB_CUSTOM, finish_handler, &err);
    nl_cb_set(cb, NL_CB_ACK, NL_CB_CUSTOM, ack_handler, &err);

    while (err > 0)
    {
        nl_recvmsgs(rttConfig.nlstate.nl_sock, cb);
    }
out:
    nl_cb_put(cb);
out_free_msg:
    nlmsg_free(msg);
    nlmsg_free(ssids);
    nlmsg_free(freqs);
    return err;
nla_put_failure:
    nl_cb_put(cb);
    nlmsg_free(msg);
    nlmsg_free(ssids);
    nlmsg_free(freqs);
    return -1;
}

uint8_t RateIs11g(uint8_t rate)
{
    unsigned int i = 0;
    for(i = 0; i < NUM_11G_RATES; i++)
    {
        if (rate == elevenGRates[i])
        {
            return true;
        }
    }
    return false;
}

void checkFor11gPhyMode(unsigned char *ie)
{
    if(ie != NULL)
    {
        uint8_t numSupRates = ie[1];
        uint8_t rateIdx = 2;
        while (numSupRates)
        {
            uint8_t rate = ie[rateIdx] & SUPPORTED_RATE_MASK;
            if (RateIs11g(rate))
            {
                rttConfig.rttPhyMode = ROME_PHY_MODE_11G;
                if (ie[rateIdx] & BASIC_RATE_MASK)
                {
                    rttConfig.rttPhyMode = ROME_PHY_MODE_11GONLY;
                    break;
                }
            }
            rateIdx++;
            numSupRates--;
        }
    }
}

void checkIfHT20AndHT40Supported(unsigned char* ie)
{
    if (ie !=NULL)
    {
        rttConfig.ht20Supported = 1;
        if(debug_enable)
        {
            printf("HT 20 supported\n");
        }
        if (ie[1] > 2)
        {
            uint16_t htCapInfo = ((ie[3] << 8) | ie[2]);
            if (htCapInfo & (1 << HT_CAP_40MHZ_SUPPORTED_BIT))
            {
                if (rttConfig.scanChannelNum > MAX_2G_CHANNEL) /* For 5G always true */
                {
                    rttConfig.ht40Supported = 1;
                    if(debug_enable)
                    {
                        printf("HT 40 supported\n");
                    }
                }
                else
                { /* for 2.4G check intollerent bit (should NOT be set) */
                    if(!(htCapInfo & (1 << HT_CAP_PROHIBIT_40MHZ_BIT)))
                    {
                        rttConfig.ht40Supported = 1;
                        if(debug_enable)
                        {
                            printf("HT 40 supported\n");
                        }
                    }
                }
            }
        }
    }
}

uint8_t isExtCapSupported(uint32_t elemBitNum, uint8_t* ie)
{
    uint8_t elemByteNum = elemBitNum / 8;
    uint8_t elemBitNumInByte = elemBitNum % 8;
    uint8_t retVal = false;

    if (ie && ie[1] > elemByteNum)
    {
        uint8_t* extendedCaps = (uint8_t*) &ie[2];
        if (extendedCaps[elemByteNum] & (1 << elemBitNumInByte))
        {
            retVal = true;
        }
    }
    return retVal;
}


void checkFor11mcRangingSupport(unsigned char* ie)
{

    rttConfig.peer11MCSupported= (isExtCapSupported(EXTENDED_CAP_11MC_SUPPORTED_BIT, ie)) ?
            true : false;
    rttConfig.peer11MCCap|= (isExtCapSupported(EXTENDED_CAP_LOC_CIVIC_SUPPORTED_BIT, ie)) ?
            LOC_CIVIC_SUPPORTED_MASK : 0;
    rttConfig.peer11MCCap |= (isExtCapSupported(EXTENDED_CAP_LCI_SUPPORTED_BIT, ie)) ?
            LCI_SUPPORTED_MASK : 0;
    rttConfig.peer11MCCap |= (isExtCapSupported(EXTENDED_CAP_INTW_ANQP_SUPPORTED_BIT, ie)) ?
            ANQP_SUPPORTED_MASK : 0;
}




void setChanelInfoForHT40(unsigned char* ie)
{
    uint8_t htOpInfo1 = (ie[3] & 0x3);
    switch (htOpInfo1)
    {
        case HT_OP_SEC_CH_NOT_PRESENT: /* No Seconday Channel present */
        {
            rttConfig.ht40Supported = false;
            printf(" No Secondary channel present\n");
            break;
        }
        case HT_OP_SEC_CH_ABOVE_PRIMARY_CH: /* Seconday Channel is above the Primary Channel */
        {
            rttConfig.bandCenterFreqForty = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum) + 10;
            break;
        }
        case HT_OP_SEC_CH_BELOW_PRIMARY_CH: /* Seconday Channel is below the Primary Channel */
        {
            rttConfig.bandCenterFreqForty = (uint16_t)getChannelFreq((uint32_t)rttConfig.scanChannelNum) - 10;
            break;
        }
        default:
        {
            printf("This should have never hapenned: %u\n",htOpInfo1);
            break;
        }
    }
    if(debug_enable)
    {
        printf("HT40 - Secondary Channel: %u\n", rttConfig.bandCenterFreqForty);
    }
}

void parse_scan_ies(unsigned char *ie, int ielen)
{
    while (ielen >= 2 && ielen >= ie[1])
    {

        switch (ie[0])
        {
            case BSSID_IE:
            {
                break;
            }
            case VENDOR_SPECIFIC_IE:
            {
                break;
            }
            case RSN_IE:
            {
                break;
            }
            case CELL_POWER_INFO_IE:
            {
                break;
            }
            case COUNTRY_CODE_IE:
            {
                break;
            }
            case SUPPORTED_RATES_IE:
            case EXT_SUPPORTED_RATES_IE:
            {
                checkFor11gPhyMode(ie);
                break;
            }
            case HT_CAP_IE:
            {
                if(debug_enable)
                {
                    printf("Found HT CAP IE\n");
                }
                checkIfHT20AndHT40Supported(ie);
                break;
            }
            case HT_OPERATION_IE:
            {
                if(debug_enable)
                {
                    printf("Found HT Operation IE\n");
                }
                if (rttConfig.ht40Supported && ie[1] > 2)
                {
                    setChanelInfoForHT40(ie);
                }
                break;
            }
            case VHT_CAP_IE:
            {
                if(debug_enable)
                {
                    printf("VHT Cap Found\n");
                }
                if (rttConfig.scanChannelNum > MAX_2G_CHANNEL)
                {
                    rttConfig.vht20Supported = 1;
                    if (rttConfig.ht40Supported)
                    {
                        rttConfig.vht40Supported = 1;
                    }
                }
                else
                {
                    rttConfig.vht20Supported = 1;
                    if (rttConfig.ht40Supported)
                    {
                        rttConfig.vht40Supported = 1;
                    }
                }
                break;
            }
            case VHT_OPERATION_IE:
            {
                if(debug_enable)
                {
                    printf("VHT Operation IE Found\n");
                }
                if (rttConfig.scanChannelNum > MAX_2G_CHANNEL)
                {
                    if (ie[1] > 2)
                    {
                        if (ie[2] > 0) /* 80 OR 160 OR (80 + 80) MHz BW supported */
                        {
                            rttConfig.vht80Supported = 1;
                            rttConfig.bandCenterFreqEighty = (uint16_t)getChannelFreq((uint32_t) ie[3]);
                            if(debug_enable)
                            {
                                printf("VHT80 - Band_center_freq1: %u\n", rttConfig.bandCenterFreqEighty);
                            }
                        }
                    }
                }
                else
                {
                    printf("VHT Operation IE Not Used\n");
                }
                break;
            }
            case EXTENDED_CAP_IE:
            {
                checkFor11mcRangingSupport(ie);
                break;
            }
            default:
            {
                if(debug_enable)
                {
                    printf("Undefined IE: 0x%x\n", ie[0]);
                }
                break;
            }
        }

        ielen -= ie[1] + 2; //Subtract the remaining IE Length
        ie += ie[1] + 2;    //move the pointer to the next IE.
    }
}

static int parse_bss_handler(struct nl_msg *msg, void *arg)
{
    struct nlattr *tb[NL80211_ATTR_MAX + 1];
    struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
    struct nlattr *bss[NL80211_BSS_MAX + 1];

    static struct nla_policy bss_policy[NL80211_BSS_MAX + 1] =
    {
            [NL80211_BSS_TSF] = { .type = NLA_U64 },
            [NL80211_BSS_FREQUENCY] = { .type = NLA_U32 },
            [NL80211_BSS_BSSID] = { .type = NLA_UNSPEC },
            [NL80211_BSS_BEACON_INTERVAL] = { .type = NLA_U16 },
            [NL80211_BSS_CAPABILITY] = { .type = NLA_U16 },
            [NL80211_BSS_INFORMATION_ELEMENTS] = { .type = NLA_UNSPEC },
            [NL80211_BSS_SIGNAL_MBM] = { .type = NLA_U32 },
            [NL80211_BSS_SIGNAL_UNSPEC] = { .type = NLA_U8 },
            [NL80211_BSS_STATUS] = { .type = NLA_U32 },
            [NL80211_BSS_SEEN_MS_AGO] = { .type = NLA_U32 },
            [NL80211_BSS_BEACON_IES] = { .type = NLA_UNSPEC },
    };

    nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
            genlmsg_attrlen(gnlh, 0), NULL);

    if (!tb[NL80211_ATTR_BSS])
    {
        printf("bss info missing! Msg Size %d",((nlmsg_hdr(msg))->nlmsg_len - NLMSG_HDRLEN));
        rttConfig.genl_integrity_check_fail = true;
        return NL_STOP;
    }

    if (nla_parse_nested(bss, NL80211_BSS_MAX,
            tb[NL80211_ATTR_BSS],
            bss_policy))
    {
        printf ( "failed to parse nested attributes!\n");
        return NL_SKIP;
    }

    if (!bss[NL80211_BSS_BSSID])
        return NL_SKIP;

    if(memcmp(rttConfig.scanMacAddr,nla_data(bss[NL80211_BSS_BSSID]),6))
    {
        return NL_SKIP;
    }
    /*only take attention to NL80211_BSS_INFORMATION_ELEMENTS attribute
      other attribute for future usage*/
    if (bss[NL80211_BSS_STATUS])
    {
    }

    if (bss[NL80211_BSS_TSF])
    {
    }
#define RTT_NL80211_BSS_BEACON_TSF 13
    if (bss[RTT_NL80211_BSS_BEACON_TSF])
    {
    }

    if (bss[NL80211_BSS_FREQUENCY])
    {
    }

    if (bss[NL80211_BSS_BEACON_INTERVAL])
    {
    }

    if (bss[NL80211_BSS_CAPABILITY])
    {
    }

    if (bss[NL80211_BSS_SIGNAL_MBM])
    {
    }

    if (bss[NL80211_BSS_SIGNAL_UNSPEC])
    {
    }

    if (bss[NL80211_BSS_INFORMATION_ELEMENTS] )
    {
        parse_scan_ies(nla_data(bss[NL80211_BSS_INFORMATION_ELEMENTS]),
                nla_len(bss[NL80211_BSS_INFORMATION_ELEMENTS]));
    }
    rttConfig.waitingForPeerInfo = 0;
    return NL_SKIP;
}

static int dump_error_handler(struct sockaddr_nl *nla, struct nlmsgerr *err,
                         void *arg)
{
    int *ret = arg;
    *ret = err->error;
    printf("Dump Error Handler called with error %d . SKIP!!",*ret);
    return NL_SKIP;
}

static int dump_finish_handler(struct nl_msg *msg, void *arg)
{
    int *ret = arg;
    struct nlmsghdr *nlh;

    *ret = 1;
    nlh = nlmsg_hdr(msg);
    rttConfig.num_finishes_for_dump++;
    if (nlh->nlmsg_type == 3)
    {
        if(debug_enable)
        {
            printf("Marking msg to be Finished");
        }
        *ret = 0;
        return NL_STOP;
    }
    return NL_SKIP;
}

static int dump_ack_handler(struct nl_msg *msg, void *arg)
{
    int *ret = arg;
    struct nlmsghdr *nlh;
    nlh = nlmsg_hdr(msg);
    *ret = 0;
    printf("Dump Ack Handler Length %d Type %d Flags %d Seq %d Sender %d",
            nlh->nlmsg_len, nlh->nlmsg_type, nlh->nlmsg_flags,
            nlh->nlmsg_seq, nlh->nlmsg_pid);
    rttConfig.num_acks_for_dump++;
    return NL_STOP;
}

static int do_scan_dump(struct nl80211_state *p_nlstate)
{
    struct nl_msg * msg;
    struct nl_cb * cb;
    int idx;
    int err = 0;

    idx = if_nametoindex(rttConfig.ifIndex);

    rttConfig.num_acks_for_dump = 1;
    rttConfig.num_finishes_for_dump = 0;
    while ((rttConfig.num_finishes_for_dump == 0)&&(rttConfig.num_acks_for_dump > 0))
    {
        rttConfig.num_acks_for_dump = 0;
        rttConfig.num_finishes_for_dump = 0;
        rttConfig.genl_integrity_check_fail = false;
        msg = nlmsg_alloc();
        if (!msg)
        {
            printf ( "failed to allocate netlink message\n");
            return 2;
        }
        cb = nl_cb_alloc(NL_CB_DEFAULT);
        if (!cb)
        {
            printf ( "failed to allocate netlink callbacks\n");
            err = 2;
            goto out_free_msg;
        }

        genlmsg_put(msg, 0, 0, rttConfig.nlstate.nl80211_id, 0,
                (NLM_F_ROOT|NLM_F_MATCH), NL80211_CMD_GET_SCAN, 0);

        NLA_PUT_U32(msg, NL80211_ATTR_IFINDEX, idx);
        nl_cb_set(cb, NL_CB_VALID, NL_CB_CUSTOM, parse_bss_handler,NULL);
        err = nl_send_auto_complete(rttConfig.nlstate.nl_sock, msg);
        if (err < 0)
        {
            printf ( "Failed to send the request to get the scan results to nl. Retry\n");
            rttConfig.num_acks_for_dump = 1; //Just to satisfy the while condition
            rttConfig.num_finishes_for_dump = 0;
            goto nla_put_failure;
        }

        err = 1; // Set err to 1, so that we can wait for err to become 0
        nl_cb_err(cb, NL_CB_CUSTOM, dump_error_handler, &err);
        nl_cb_set(cb, NL_CB_FINISH, NL_CB_CUSTOM, dump_finish_handler, &err);
        nl_cb_set(cb, NL_CB_ACK, NL_CB_CUSTOM, dump_ack_handler, &err);

        while ((err > 0) && (false == rttConfig.genl_integrity_check_fail))
        {
            nl_recvmsgs(rttConfig.nlstate.nl_sock, cb);
        }

        if ((rttConfig.genl_integrity_check_fail == true) && (rttConfig.num_finishes_for_dump == 0))
        {
            rttConfig.num_acks_for_dump = 1;
            rttConfig.genl_integrity_check_fail = false;
            printf ( "GENL Msg Integrity Check Failed");
        }

nla_put_failure:
        nl_cb_put(cb); //Free the CB.
out_free_msg:
        nlmsg_free(msg); //Free the allocated Message
        if ((rttConfig.num_finishes_for_dump == 0) && (rttConfig.num_acks_for_dump > 0))
        {
            printf ( "RETRY: Finish NL Msg err code %d Num Finish %d Num Ack %d",
                    err,rttConfig.num_finishes_for_dump,rttConfig.num_acks_for_dump);
            nl80211_cleanup(&rttConfig.nlstate);
            nl80211_init(&rttConfig.nlstate);
        }
    }
    return err;
}

void triggerScanUsingNL()
{
    int err;
    err = nl80211_init(&rttConfig.nlstate);
    if (!err)
    {
        do
        {
            err = do_trigger_scan();
            if (err != 0)
            {
                printf("Trigger scan failed\n");
                break;
            }
            if(debug_enable)
            {
                printf( "wait for netlink message\n");
            }
            err = do_listen_events(&rttConfig.nlstate, 3);
            if (err >= 0)
            {
                do_scan_dump(&rttConfig.nlstate);
            }
            nl80211_cleanup(&rttConfig.nlstate);
        }
        while(0);
    }
    return;
}

static void *rxWorkerThread(void *thread_param)
{
    struct timeval tv;
    fd_set read_fd_set;
    int max_fd;
    int retval;
    int timeout_val = 5;
    RomeNlMsgType msgType;
    while(1)
    {
        max_fd = rttConfig.nl_sock_fd;
        if (max_fd <= 0)
        {
            printf("rxWorkerThread: socket not initialized %d\n", rttConfig.nl_sock_fd);
            return NULL;
        }
        // At least one socket is valid
        tv.tv_sec = 5;
        tv.tv_usec = 0;
        FD_ZERO(&read_fd_set);
        if (rttConfig.nl_sock_fd > 0)
        {
            FD_SET(rttConfig.nl_sock_fd, &read_fd_set);
        }
        else
        {
            printf("rxWorkerThread: Bad netlink socket %d\n", rttConfig.nl_sock_fd);
        }

        if (timeout_val >= 0)
        {
            retval = select(max_fd+1, &read_fd_set, NULL,NULL,&tv);
        }
        else
        {
            retval = select(max_fd+1, &read_fd_set, NULL,NULL,NULL);
        }
        if (retval == 0) //This means the select timed out
        {
            if (rttConfig.waitingRsp && !rttConfig.retryNum)
            {
                rttConfig.retryNum++;
                printf("rxWorkerThread: Req have sent. wait one more time for the response\n");
                continue;
            }
            else if(rttConfig.waitingRsp && rttConfig.retryNum)
            {
                rttConfig.retryNum = 0;
                printf("rxWorkerThread: Do not continue to wait the response,Error Exit\n");
                return NULL;
            }
            else
            {
                if(debug_enable)
                {
                    printf("rxWorkerThread: No Messages Received!! Timeout,but continue...\n");
                }
                continue;
            }
        }
        if (retval < 0) //This means the select failed with some error
        {
            printf("rxWorkerThread: No response received from FW!!\n");
            return NULL;
        }
        if (retval > 0)
        {
            recvNLMessage(&msgType, &rttConfig.NlBuf[0], sizeof(rttConfig.NlBuf));
        }

        if (msgType == ROME_REG_RSP_MSG)
        {
            RomeExtractRegRsp(&rttConfig.NlBuf[0]);
            rttConfig.waitingRsp = 0;
            if (rttConfig.reqType == chanInfoReq)
            {
                sendChannelInfoReqToCld();
            }
            else if (rttConfig.reqType == rangeCapReq)
            {
                sendRangingCapReq();
            }
            else if (rttConfig.reqType == rangeScanReq)
            {
                sendChannelInfoReqToCld();
            }
        }
        else if (msgType == ROME_CHANNEL_INFO_MSG /*ROME_RTT_CHANNEL_INFO_MSG*/)
        {
            RomeExtractChannelInfo(&rttConfig.NlBuf[0]); //RomeExtractRttChannelInfo(&NlBuf);
            rttConfig.waitingRsp = 0;
            if (rttConfig.reqType == rangeScanReq)
            {
                sendRangingScanReq();
            }
        }
        else if (msgType == ROME_RANGING_CAP_MSG /*TARGET_OEM_CAPABILITY_RSP*/)
        {
            RomeExtractRttRangingCap(&rttConfig.NlBuf[0]);
            rttConfig.waitingRsp = 0;
        }
        else if (msgType == ROME_RANGING_MEAS_MSG)
        {
            RomeParseRangingMeas(&rttConfig.NlBuf[0]);
            rttConfig.waitingRsp = 0;
        }
    }
}

int main(int argc, char *argv[])
{
    int ret;
    int i;

    if (argc <= 1)
    {
        printf("No execution option input. Exit it!\n");
        return -1;
    }
    memset(&rttConfig, 0, sizeof(rttConfig));

    /* init socket */
    rttConfig.nl_sock_fd = create_nl_sock();
    if (rttConfig.nl_sock_fd < 0)
    {
        printf("fail create socket. Exit it!\n");
        return -1;
    }

    if (argc >= 2)
    {
        ret = pthread_create(&rttConfig.rxNlThread, NULL, rxWorkerThread, NULL);
        if (ret != 0)
        {
            printf("fail create rxNlThread. Exit it!\n");
            close(rttConfig.nl_sock_fd);
            return -1;
        }
        for(i = 1; i < argc; i++)
        {
            if (!strcmp(argv[i], "-c"))
            {
                i++;
                if (!strcmp(argv[i],"RegReq"))
                {
                    sendRegReq();
                }
                else if (!strcmp(argv[i],"ChannelInfoReq"))
                {
                    rttConfig.reqType = chanInfoReq;
                    sendRegReq();
                }
                else if (!strcmp(argv[i],"RangingCapReq"))
                {
                    rttConfig.reqType = rangeCapReq;
                    sendRegReq();
                }
                else if (!strcmp(argv[i],"RangingScanReq"))
                {
                    rttConfig.reqType = rangeScanReq;
                    rttConfig.waitingForPeerInfo = 1;
                    /*try trigger scan up to three times in case the AP not found*/
                    while(rttConfig.waitingForPeerInfo &&
                            rttConfig.scanRetryTimes < 3)
                    {
                        triggerScanUsingNL();
                        if (rttConfig.waitingForPeerInfo == 0)
                        {
                            break;
                        }
                        rttConfig.scanRetryTimes++;
                    }
                    if(rttConfig.waitingForPeerInfo == 0)
                    {
                        sendRegReq();
                    }
                    else
                    {
                        printf("no the specific peer in the scan result list, please try again\n");
                        return -1;
                    }
                }
                else
                {
                    printf("not expected cmd, Exit it!!\n");
                    return -1;
                }
            }
            else if (!strcmp(argv[i], "-n"))
            {
                i++;
                rttConfig.scanChannelNum = atoi(argv[i]);
            }
            else if (!strcmp(argv[i], "-m"))
            {
                i++;
                sscanf(argv[i],
                       "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
                       &rttConfig.scanMacAddr[0],
                       &rttConfig.scanMacAddr[1],
                       &rttConfig.scanMacAddr[2],
                       &rttConfig.scanMacAddr[3],
                       &rttConfig.scanMacAddr[4],
                       &rttConfig.scanMacAddr[5]);
            }
            else if (!strcmp(argv[i], "-p"))
            {
                i++;
                rttConfig.isQTIPeer = atoi(argv[i]);
            }
            else if (!strcmp(argv[i], "-w"))
            {
                i++;
                rttConfig.scanBandWidth = atoi(argv[i]);
            }
            else if (!strcmp(argv[i], "-h"))
            {
                i++;
                rttConfig.scanPreamble = atoi(argv[i]);
            }
            else if (!strcmp(argv[i], "-b"))
            {
                i++;
                rttConfig.burstNum = atoi(argv[i]);
            }
            else if (!strcmp(argv[i], "-t"))
            {
                i++;
                rttConfig.rttFrameType = atoi(argv[i]);
            }
            else if (!strcmp(argv[i], "-i"))
            {
                i++;
                memcpy(rttConfig.ifIndex,argv[i],strlen(argv[i]));
                rttConfig.ifIndex[strlen(argv[i])] = '\0';
            }
            else if (!strcmp(argv[i], "-d"))
            {
                i++;
                debug_enable = atoi(argv[i]);
            }
            else
            {
                printf("no corresponding option, EXIT it!\n");
                return -1;
            }
        }
    }
    pthread_join(rttConfig.rxNlThread, NULL);
    return 0;
}


