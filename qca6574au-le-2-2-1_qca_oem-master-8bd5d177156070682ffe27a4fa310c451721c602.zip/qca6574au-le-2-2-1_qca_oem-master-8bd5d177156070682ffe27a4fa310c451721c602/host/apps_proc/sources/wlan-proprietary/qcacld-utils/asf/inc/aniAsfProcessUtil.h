/*
 * Copyright (c) 2013 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 *
 */


/*
 * This file aniAsfEvent.h is for the Event Manager (Function declarations)
 * Author:  U. Loganathan
 * Date:    Jul 1st 2002
 * History:-
 * Date     Modified by Modification Information
 *
 */

#ifndef _ANI_ASF_PROCESS_UTIL_H_
#define _ANI_ASF_PROCESS_UTIL_H_

extern void  aniAsfDaemonize(void);

#endif /* _ANI_ASF_PROCESS_UTIL_H_ */
