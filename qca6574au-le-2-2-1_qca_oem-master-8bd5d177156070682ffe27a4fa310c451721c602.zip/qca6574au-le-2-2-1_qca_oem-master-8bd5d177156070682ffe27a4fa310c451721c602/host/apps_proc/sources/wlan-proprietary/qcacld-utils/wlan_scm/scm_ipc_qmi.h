/**
 * Copyright (c) 2016 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */

#ifndef __SCM_IPC_QMI_H__
#define __SCM_IPC_QMI_H__

#include "scm_wlan.h"
#define SCM_MSGR_MAX_CLI 2

int scm_ipc_qmi_init(struct scm_data *sd);
#endif
