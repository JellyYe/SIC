/*
 * Copyright (c) 2009-2010, 2012-2014, 2019 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */

/*
 * 2012-2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */
//------------------------------------------------------------------------------
// 2009-2010 Atheros Corporation.  All rights reserved.
// $ATH_LICENSE_HOSTSDK0_C$
//------------------------------------------------------------------------------
//==============================================================================
// Author(s): ="Atheros"
//==============================================================================

#ifndef __GMBOXIF_H__
#define __GMBOXIF_H__

#ifndef ATH_TARGET
//#include "athstartpack.h"
#endif

/* GMBOX interface definitions */

#define AR6K_GMBOX_CREDIT_COUNTER       1   /* we use credit counter 1 to track credits */
#define AR6K_GMBOX_CREDIT_SIZE_COUNTER  2   /* credit counter 2 is used to pass the size of each credit */


    /* HCI UART transport definitions when used over GMBOX interface */
#define HCI_UART_COMMAND_PKT 0x01
#define HCI_UART_ACL_PKT     0x02
#define HCI_UART_SCO_PKT     0x03
#define HCI_UART_EVENT_PKT   0x04

    /* definitions for BT HCI packets */
typedef  struct {
    uint16_t Flags_ConnHandle;
    uint16_t Length;
} __attribute__ ((packed)) BT_HCI_ACL_HEADER;
//__attribute__ ((packed))
typedef  struct {
    uint16_t Flags_ConnHandle;
    uint8_t  Length;
} __attribute__ ((packed)) BT_HCI_SCO_HEADER;
//__attribute__ ((packed))
typedef  struct {
    uint16_t OpCode;
    uint8_t  ParamLength;
} __attribute__ ((packed)) BT_HCI_COMMAND_HEADER;
//__attribute__ ((packed))
typedef struct {
    uint8_t  EventCode;
    uint8_t  ParamLength;
} __attribute__ ((packed)) BT_HCI_EVENT_HEADER;
//__attribute__ ((packed))
/* MBOX host interrupt signal assignments */

#define MBOX_SIG_HCI_BRIDGE_MAX      8
#define MBOX_SIG_HCI_BRIDGE_BT_ON    0
#define MBOX_SIG_HCI_BRIDGE_BT_OFF   1
#define MBOX_SIG_HCI_BRIDGE_BAUD_SET 2
#define MBOX_SIG_HCI_BRIDGE_PWR_SAV_ON    3
#define MBOX_SIG_HCI_BRIDGE_PWR_SAV_OFF   4

/* Host interrupts target to change baud rate and
 * baud rate info is stored in scratch registers 4 and 5
 */
#define LSB_SCRATCH_IDX     4
#define MSB_SCRATCH_IDX     5

#ifndef ATH_TARGET
//#include "athendpack.h"
#endif

#endif /* __GMBOXIF_H__ */

