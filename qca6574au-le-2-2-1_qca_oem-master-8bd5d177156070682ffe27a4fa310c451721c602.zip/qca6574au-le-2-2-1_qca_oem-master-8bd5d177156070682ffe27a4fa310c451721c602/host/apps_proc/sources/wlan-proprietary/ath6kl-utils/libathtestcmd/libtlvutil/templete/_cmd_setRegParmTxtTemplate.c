
/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

//This is an auto-generated file, from the given header file /home/atheros/Perforce/sskwak_atheros-HP-Z220-CMT-Workstation_298/components/rel/wlanfw.cnss/1.0.2/include/systemtools/common/cmdSetRegParms.h
#include "parmTxtTemplate.h"

_TESTFLOW_TXT_PARM_TEMPLATE _setRegParm_txt_template[] = {
    {"regAddr", 3, 0, 4},
    {"value", 3, 4, 4},
    {"flag", 2, 8, 2},
};
