
/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

//This is an auto-generated file, from the given header file /home/atheros/Perforce/sskwak_atheros-HP-Z220-CMT-Workstation_298/components/rel/wlanfw.cnss/1.0.2/include/systemtools/common/cmdCalParms.h
#include "parmTxtTemplate.h"

_TESTFLOW_TXT_PARM_TEMPLATE _calParm_txt_template[] = {
    {"addrMode0", 3, 0, 4},
    {"addrMode1", 3, 4, 4},
    {"addrMode2", 3, 8, 4},
    {"addrMode3", 3, 12, 4},
    {"addrMode4", 3, 16, 4},
    {"addrMode5", 3, 20, 4},
    {"addrMode6", 3, 24, 4},
    {"addrMode7", 3, 28, 4},
    {"addrMode8", 3, 32, 4},
    {"addrMode9", 3, 36, 4},
    {"addrMode10", 3, 40, 4},
    {"addrMode11", 3, 44, 4},
    {"addrMode12", 3, 48, 4},
    {"addrMode13", 3, 52, 4},
    {"addrMode14", 3, 56, 4},
    {"addrMode15", 3, 60, 4},
    {"value0", 3, 64, 4},
    {"value1", 3, 68, 4},
    {"value2", 3, 72, 4},
    {"value3", 3, 76, 4},
    {"value4", 3, 80, 4},
    {"value5", 3, 84, 4},
    {"value6", 3, 88, 4},
    {"value7", 3, 92, 4},
    {"value8", 3, 96, 4},
    {"value9", 3, 100, 4},
    {"value10", 3, 104, 4},
    {"value11", 3, 108, 4},
    {"value12", 3, 112, 4},
    {"value13", 3, 116, 4},
    {"value14", 3, 120, 4},
    {"value15", 3, 124, 4},
    {"mask0", 3, 128, 4},
    {"mask1", 3, 132, 4},
    {"mask2", 3, 136, 4},
    {"mask3", 3, 140, 4},
    {"mask4", 3, 144, 4},
    {"mask5", 3, 148, 4},
    {"mask6", 3, 152, 4},
    {"mask7", 3, 156, 4},
    {"mask8", 3, 160, 4},
    {"mask9", 3, 164, 4},
    {"mask10", 3, 168, 4},
    {"mask11", 3, 172, 4},
    {"mask12", 3, 176, 4},
    {"mask13", 3, 180, 4},
    {"mask14", 3, 184, 4},
    {"mask15", 3, 188, 4},
};
