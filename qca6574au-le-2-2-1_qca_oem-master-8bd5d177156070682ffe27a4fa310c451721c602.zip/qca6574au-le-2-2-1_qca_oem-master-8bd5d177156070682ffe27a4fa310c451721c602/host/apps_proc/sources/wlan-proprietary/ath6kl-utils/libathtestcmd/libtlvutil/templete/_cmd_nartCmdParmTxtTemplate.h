
/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

//This is an auto-generated file, from the given header file /home/atheros/Perforce/sskwak_atheros-HP-Z220-CMT-Workstation_298/components/rel/wlanfw.cnss/1.0.2/include/systemtools/common/cmdNartGenericCmdParms.h
#include "parmTxtTemplate.h"

#define NUM_OF__nartCmdParm sizeof(_nartCmdParm_txt_template)/sizeof(_TESTFLOW_TXT_PARM_TEMPLATE)
extern _TESTFLOW_TXT_PARM_TEMPLATE _nartCmdParm_txt_template[5/*NUM_OF__nartCmdParm*/];
