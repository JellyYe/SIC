
/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

//This is an auto-generated file, from the given header file /home/atheros/Perforce/sskwak_atheros-HP-Z220-CMT-Workstation_298/components/rel/wlanfw.cnss/1.0.2/include/systemtools/common/cmdTxStatus.h
#include "parmTxtTemplate.h"

#define NUM_OF__txStatusParm sizeof(_txStatusParm_txt_template)/sizeof(_TESTFLOW_TXT_PARM_TEMPLATE)
extern _TESTFLOW_TXT_PARM_TEMPLATE _txStatusParm_txt_template[25/*NUM_OF__txStatusParm*/];
