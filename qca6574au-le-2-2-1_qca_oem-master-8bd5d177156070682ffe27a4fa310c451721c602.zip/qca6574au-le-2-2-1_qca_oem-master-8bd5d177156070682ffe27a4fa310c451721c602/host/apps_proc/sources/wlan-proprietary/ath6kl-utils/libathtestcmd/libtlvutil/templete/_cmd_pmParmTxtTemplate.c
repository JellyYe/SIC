
/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

//This is an auto-generated file, from the given header file /home/atheros/Perforce/sskwak_atheros-HP-Z220-CMT-Workstation_298/components/rel/wlanfw.cnss/1.0.2/include/systemtools/common/cmdPmParms.h
#include "parmTxtTemplate.h"

_TESTFLOW_TXT_PARM_TEMPLATE _pmParm_txt_template[] = {
    {"mode", 3, 0, 4},
};
