
/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

#if 0
This is an auto-generated file, from the given header file /home/atheros/Perforce/sskwak_atheros-HP-Z220-CMT-Workstation_298/components/rel/wlanfw.cnss/1.0.2/include/systemtools/common/cmdNartGenericCmdParms.h
#endif
#include "parmTxtTemplate.h"

_TESTFLOW_TXT_PARM_TEMPLATE _nartCmdParm_txt_template[] = {
    {"commandId", 3, 0, 4},
    {"param1", 3, 4, 4},
    {"param2", 3, 8, 4},
    {"param3", 3, 12, 4},
    {"data", 1, 16, 1024},
};
