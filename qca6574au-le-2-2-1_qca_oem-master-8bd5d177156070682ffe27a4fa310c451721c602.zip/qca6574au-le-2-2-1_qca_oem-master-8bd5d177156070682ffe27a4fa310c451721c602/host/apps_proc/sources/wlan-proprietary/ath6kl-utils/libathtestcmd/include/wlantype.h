/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

#if !defined(_WLANTYPE_H)
#define _WLANTYPE_H
// Sean+
/*
typedef	unsigned int uint32_t;
typedef	unsigned char uint8_t;
typedef uint8_t u_char;
typedef	unsigned short uint16_t;
typedef unsigned long size_t;
*/
// need these header for typedef
#include <sys/types.h>
#include <stdint.h>
// Sean-
#endif //#if !defined(_WLANTYPE_H)
