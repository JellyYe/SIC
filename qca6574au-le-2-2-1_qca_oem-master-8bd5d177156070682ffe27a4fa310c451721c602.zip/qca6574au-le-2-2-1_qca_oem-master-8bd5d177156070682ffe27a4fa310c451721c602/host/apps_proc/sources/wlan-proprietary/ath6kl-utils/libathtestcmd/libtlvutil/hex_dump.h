/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary.
 */

#if !defined(_HEX_DUMP_H)
#define  _HEX_DUMP_H

void print_hex_dump(void *buf, size_t len);

#endif

