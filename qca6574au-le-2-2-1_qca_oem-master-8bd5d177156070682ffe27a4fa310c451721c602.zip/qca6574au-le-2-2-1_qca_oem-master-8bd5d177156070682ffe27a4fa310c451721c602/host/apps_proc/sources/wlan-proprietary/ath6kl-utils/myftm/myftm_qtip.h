/*==========================================================================

                     FTM QTIP Header File

# Copyright (c) 2016 Qualcomm Atheros Inc.
# All Rights Reserved.
# Qualcomm Atheros Proprietary and Confidential.

===========================================================================*/

#define MAXSTREAMLENGTH 6148


void cmdReplyFunc(void *buf, int len);
void prtStream(char *stream, int streamLen);
void qtip();
