#!/bin/sh

# Copyright (c) 2018 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.

SCRIPT_FOLDER="$(dirname "${BASH_SOURCE}")"
AGL_WORK_SPACE="$(readlink -f ${SCRIPT_FOLDER}/../../..)"

BBLAYERS_CONFIG="conf/bblayers.conf"

if [ ! -f ${BBLAYERS_CONFIG} ]; then
    echo "Can't find file ${BBLAYERS_CONFIG}"
    exit 1
fi

if grep -q 'meta-qti-connectivity-prop' ${BBLAYERS_CONFIG}; then
    echo "BBLAYERS for proprietary already updated."
    exit 0
fi

cat >> ${BBLAYERS_CONFIG} <<EOF

##QTI Connectivity Prop META layers support
BBLAYERS += "${AGL_WORK_SPACE}/sources/meta-qti-connectivity-prop"

## BBMASK for Dual WiFi Setup with Prop
BBMASK.="|meta-qti-bsp-prop/recipes-connectivity/wlan-proprietary/ath6kl-utils_git.bb"
BBMASK.="|meta-qti-bsp-prop/recipes-connectivity/wlan-proprietary/qcacld-utils_git.bb"
BBMASK.="|meta-qti-connectivity-prop/recipes-products/images/standalone-auto-image.bbappend"
BBMASK.="|meta-qti-connectivity-prop/recipes-products/images/standalone-imx8auto-image-prop.bb"
BBMASK.="|meta-qti-connectivity-prop/recipes-products/images/automotive-connx-image.bbappend"
BBMASK.="|meta-qti-connectivity-prop/recipes-connectivity/wlan-proprietary/wlan-rtt_git.bb"
BBMASK.="|meta-qti-connectivity-prop/recipes-connectivity/synergy/synergy-bt.bb"
BBMASK.="|meta-qti-connectivity-prop/recipes-connectivity/wlan-proprietary/qcmbr_git.bb"
BBMASK.="|meta-qti-connectivity-prop/recipes-connectivity/wlan-proprietary/ssr-demo_git.bb"
EOF
