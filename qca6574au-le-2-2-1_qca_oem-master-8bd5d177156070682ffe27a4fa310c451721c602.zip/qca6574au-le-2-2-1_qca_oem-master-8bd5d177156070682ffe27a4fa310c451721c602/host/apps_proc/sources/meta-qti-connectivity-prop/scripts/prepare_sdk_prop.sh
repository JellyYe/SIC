#!/bin/sh

# Copyright (c) 2018 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.

echo 'BBLAYERS += "${BSPDIR}/sources/meta-qti-connectivity-prop"' >>  conf/bblayers.conf

echo  'MACHINE_ESSENTIAL_EXTRA_RRECOMMENDS += "ath6kl-utils"
MACHINE_ESSENTIAL_EXTRA_RRECOMMENDS += "qcmbr"
MACHINE_ESSENTIAL_EXTRA_RRECOMMENDS += "qcacld-utils"
MACHINE_ESSENTIAL_EXTRA_RRECOMMENDS += "ssr-demo"
MACHINE_ESSENTIAL_EXTRA_RRECOMMENDS += "wlan-rtt"
' >> conf/local.conf
